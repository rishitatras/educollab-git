package deleteAnswer;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import detailAnswerscreen.detailAnswerscreen;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class deleteAnswerTest extends BaseTest { // sprint 54 test case AIO test no 288

	deleteAnswer   Answerobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To Verify Delete Answer Functionality in My Answer").assignCategory("Regression Test");
		Answerobject = new deleteAnswer(driver);
		
		Thread.sleep(10000);
		clickOnElement(Answerobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(Answerobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(Answerobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(Answerobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(Answerobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(Answerobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(Answerobject.getoPassWord());
		sendValuesToElement(Answerobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(8000);
		clickOnElement(Answerobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(Answerobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
	
		
		Thread.sleep(5000);
		clickOnElement(Answerobject.getomeenubar());
		test.log(LogStatus.PASS,"clicked on meenu bar");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(968, 880)).perform();
		Thread.sleep(5000);
		
		Thread.sleep(5000);
		clickOnElement(Answerobject.getoSecondquestion());
		test.log(LogStatus.PASS,"clicked on secondque");
		
		Thread.sleep(5000);
		clickOnElement(Answerobject.getodelete());
		test.log(LogStatus.PASS,"clicked on delete");
       Thread.sleep(3000);		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (54).xlsx", "Sheet1", "deleteAnswerTest");
	}		

	
	
	
}
