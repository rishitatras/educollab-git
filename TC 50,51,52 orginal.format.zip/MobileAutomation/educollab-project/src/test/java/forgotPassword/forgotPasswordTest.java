package forgotPassword;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;


public class forgotPasswordTest extends BaseTest {

	

	forgotPassword otpobject;
		
		
		@Test(dataProvider="loginData")
		public void ValidCredentials(String email,String password) throws InterruptedException {
			test = extent.startTest("Valid credentials Success Login ").assignCategory("Regression Test");
			otpobject = new forgotPassword(driver);
			Thread.sleep(10000);
			
			clickOnElement(otpobject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Default Login");
			
			VerifyelementIsDisplayed(otpobject.getoDefaultLoginHeader());
			test.log(LogStatus.PASS, "Login Header Is Displayed");
			
			VerifyelementIsDisplayed(otpobject.getoDefaultPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
			
			VerifyelementIsDisplayed(otpobject.getoPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
			
			Thread.sleep(8000);
			clickOnElement(otpobject.getoForgotPassword());
			test.log(LogStatus.PASS, "Clicked on forgotpassword");
			
			Thread.sleep(8000);
			clickOnElement(otpobject.getoEmail());
			sendValuesToElement(otpobject.getoEmail(),email);
			test.log(LogStatus.PASS,"clicked on email text");
			
			Thread.sleep(8000);
			clickOnElement(otpobject.getoSendotp());
			test.log(LogStatus.PASS,"clicked on otp ");
			
		}
		private String getoUserName() {
			return null;
			// TODO Auto-generated method stub
			//	return null;
		}

		@DataProvider(name="loginData")
		public Object[][] getLoginData() throws IOException{
			return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (19).xlsx", "Sheet1", "forgotPasswordTest");
		}
	
			
}	
			
			
			
				
			

