package questionTypefilter;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import filterButton.filterButton;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import questionTypeFilter.questionTypeFilter;

public class questionTypeFilterTest extends BaseTest { // sprint 53 test case AIO test no 279

	questionTypeFilter   questionTypeobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("Valid credentials Success Login ").assignCategory("Regression Test");
		questionTypeobject = new questionTypeFilter(driver);
		
		Thread.sleep(15000);
		clickOnElement(questionTypeobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(questionTypeobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(questionTypeobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(questionTypeobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(questionTypeobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(questionTypeobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(questionTypeobject.getoPassWord());
		sendValuesToElement(questionTypeobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(5000);
		clickOnElement(questionTypeobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(questionTypeobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
		 
		Thread.sleep(5000);
		clickOnElement(questionTypeobject.getomennubar());
		test.log(LogStatus.PASS,"clicked on mennubar");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(968, 375)).perform();
        Thread.sleep(5000);
        
        
		Thread.sleep(5000);
		clickOnElement(questionTypeobject.getofiltericon());
		test.log(LogStatus.PASS,"clicked on filtericon");
		
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(119, 761)).perform();
        Thread.sleep(5000);
        
        Thread.sleep(5000);
		clickOnElement(questionTypeobject.getoapplybutton());
		test.log(LogStatus.PASS,"clicked on apply button");
		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (48).xlsx", "Sheet1", "questionTypeFilterTest");
	}	
        
        
        
		
}
