package photoAttachment;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;


import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class photoAttachmentTest extends BaseTest {

	photoAttachment   photoobject;  // sprint 52 Aio test case 262
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String text,String coin,String tag) throws InterruptedException {
		test = extent.startTest("To verify ask question functionality with Photo Attachment from camera").assignCategory("Regression Test");
		photoobject = new photoAttachment(driver);
		
		Thread.sleep(15000);
		clickOnElement(photoobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(photoobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(photoobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(photoobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(4000);
		clickOnElement(photoobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(photoobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(4000);
		clickOnElement(photoobject.getoPassWord());
		sendValuesToElement(photoobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(4000);
		clickOnElement(photoobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(12000);
		clickOnElement(photoobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
		Thread.sleep(3000);


		(new TouchAction(driver)).tap(PointOption.point(961, 1971)).perform();
		
		Thread.sleep(5000);
		clickOnElement(photoobject.getotext());
		sendValuesToElement(photoobject.getotext(),text);
		test.log(LogStatus.PASS,"enter the text");
		
		Thread.sleep(5000);
		clickOnElement(photoobject.getocoin());
		sendValuesToElement(photoobject.getocoin(),coin);
		test.log(LogStatus.PASS,"enterthe coins");
		
		Thread.sleep(5000);
		clickOnElement(photoobject.getoquestiiontag());
		sendValuesToElement(photoobject.getoquestiiontag(),tag);
		test.log(LogStatus.PASS,"enterthe tag");
		
		Thread.sleep(5000);
		clickOnElement(photoobject.getotagcategories());
		test.log(LogStatus.PASS,"enterthe categories");
		
		Thread.sleep(5000);
		clickOnElement(photoobject.getocategories());
		test.log(LogStatus.PASS,"enter the catory");
		
		Thread.sleep(5000);
		clickOnElement(photoobject.getoselectcategory());
		test.log(LogStatus.PASS,"enter the select catory");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(828, 1939)).perform();

		Thread.sleep(5000);
		clickOnElement(photoobject.getouploadfile());
		test.log(LogStatus.PASS,"enter the select uploadfile");
		
		Thread.sleep(5000);
		clickOnElement(photoobject.getophoto());
		test.log(LogStatus.PASS,"enter the select photo");
		
		Thread.sleep(5000);
		clickOnElement(photoobject.getophotoselect());
		test.log(LogStatus.PASS,"enter the photo");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(821, 2149)).perform();
		
		test.log(LogStatus.PASS,"enter the submit");
		Thread.sleep(10000);
		
		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (36).xlsx", "Sheet1", "photoAttachmentTest");
	}
		
		
}
		

	

