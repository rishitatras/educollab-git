package myAnswerscreen;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import editMyanswer.editMyanswer;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class myAnswerscreenTest extends BaseTest { // sprint 53 test case AIO test no 285

	myAnswerscreen   screenobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify listing of answered question in my answer screen ").assignCategory("Regression Test");
		screenobject = new myAnswerscreen(driver);
		
		Thread.sleep(15000);
		clickOnElement(screenobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		
		VerifyelementIsDisplayed(screenobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(screenobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(screenobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(screenobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(screenobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(screenobject.getoPassWord());
		sendValuesToElement(screenobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(15000);
		clickOnElement(screenobject.getoLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		clickOnElement(screenobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
	
		
		Thread.sleep(5000);
		clickOnElement(screenobject.getomeenubar());
		test.log(LogStatus.PASS,"clicked on meenu bar");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(964, 873)).perform();
		Thread.sleep(5000);
		 
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (51).xlsx", "Sheet1", "myAnswerscreenTest");
	}		
		
		
		
	
	}




