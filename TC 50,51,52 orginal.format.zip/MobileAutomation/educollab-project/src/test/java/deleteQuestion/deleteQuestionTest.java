package deleteQuestion;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class deleteQuestionTest extends BaseTest { // sprint 52 test case AIO test no 279 

	deleteQuestion   Questionobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify Delete Question functionality").assignCategory("Regression Test");
		Questionobject = new deleteQuestion(driver);
		
		Thread.sleep(15000);
		clickOnElement(Questionobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		
		VerifyelementIsDisplayed(Questionobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(Questionobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(Questionobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(Questionobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(Questionobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(Questionobject.getoPassWord());
		sendValuesToElement(Questionobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(5000);
		clickOnElement(Questionobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getomeenubar());
		test.log(LogStatus.PASS,"clicked on meenu bar");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(957, 733)).perform();
        Thread.sleep(5000);
        
        Thread.sleep(5000);
		clickOnElement(Questionobject.getothreeidot());
		test.log(LogStatus.PASS,"clicked on three idot");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getodeleteoption());
		test.log(LogStatus.PASS,"clicked on delete");
		
		Thread.sleep(5000);
		//clickOnElement(Questionobject.getoyes());
		//test.log(LogStatus.PASS,"clicked on yes");
		
		
		
		
		
		
		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (39).xlsx", "Sheet1", "deleteQuestionTest");
	}	

	
	
}
