package SubscribedCourse;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import FeaturedCourse.FeaturedCourse;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class SubscribedCourseTest extends BaseTest {

	SubscribedCourse SubscribedObject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("Valid credentials Success Login ").assignCategory("Regression Test");
		SubscribedObject = new SubscribedCourse (driver);
		
		Thread.sleep(12000);
		clickOnElement(SubscribedObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(SubscribedObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(SubscribedObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(SubscribedObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(2000);
		//sendValuesToElement(CoursesObject.getoUserName(), email);
		clickOnElement(SubscribedObject.getoUserName());
		Thread.sleep(500);
		sendValuesToElement(SubscribedObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(500);
		clickOnElement(SubscribedObject.getoPassWord());
		sendValuesToElement(SubscribedObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		Thread.sleep(10000);
		buttonClick(SubscribedObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		
		Thread.sleep(15000);
		clickOnElement(SubscribedObject.getOHomeTab());
		test.log(LogStatus.PASS,"clicked on the Home tab");
		 
		Thread.sleep(1000);
		(new TouchAction(driver)).press(PointOption.point(768, 2034))
		  .moveTo(PointOption.point(824, 482))
		  .release()
		  .perform();
		Thread.sleep(1000);
		//Thread.sleep(20000);
//		(new TouchAction(driver)).press(PointOption.point(775, 1248))
//		  .moveTo(PointOption.point(792, 775))
//		  .release()
//		  .perform();
//		(new TouchAction(driver)).press(PointOption.point(768, 2034))
//		  .moveTo(PointOption.point(824, 482))
//		  .release()
//		  .perform();
//	Thread.sleep(15000); 
		
//		test.log(LogStatus.PASS,"clicked on the subscribed button");
//		Thread.sleep(8000);
		
		(new TouchAction(driver)).tap(PointOption.point(936, 2054)).perform();
		Thread.sleep(15000);
		test.log(LogStatus.PASS,"clicked on the subscribed course");
		}
	private String getoUserName() {
		return null;
		//TODO Auto-generated method stub
			//return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (10).xlsx", "Sheet1", "SubscribedCourseTest");
	}
	
}
