package login;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;

public class loginTest extends BaseTest {

	login inobject;                            // sprint 51 Aio test case no : 252
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify login functionality with vaild credentials").assignCategory("Regression Test");
		inobject = new login(driver);
		Thread.sleep(8000);
		
		clickOnElement(inobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		VerifyelementIsDisplayed(inobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(inobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(inobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(10000);
		clickOnElement(inobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(inobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(5000);
		clickOnElement(inobject.getoPassWord());
		Thread.sleep(1000);
		sendValuesToElement(inobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(4000);
		clickOnElement(inobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
	Thread.sleep(3000);
		
}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"\\data\\EduDataSheet (17).xlsx", "Sheet1", "loginTest");
	}
}