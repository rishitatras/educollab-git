package feedbackTopiclevel;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;


import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class feedbackTopiclevelTest extends BaseTest {

	feedbackTopiclevel TopicObject;    // sprint 50 test case 180
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify topic level feedback").assignCategory("Regression Test");
		TopicObject = new feedbackTopiclevel(driver);
		Thread.sleep(10000);
		
		clickOnElement(TopicObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		
		VerifyelementIsDisplayed(TopicObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(TopicObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(TopicObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(8000);
		clickOnElement(TopicObject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(TopicObject.getoUserName(), email);
		Thread.sleep(1000);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(8000);
		clickOnElement(TopicObject.getoPassWord());
		Thread.sleep(1000);
		sendValuesToElement(TopicObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		Thread.sleep(5000);
		buttonClick(TopicObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		buttonClick(TopicObject.getoCoureseButton());
        test.log(LogStatus.PASS,"clicked on course button");
        
        Thread.sleep(12000);
        (new TouchAction(driver)).press(PointOption.point(835, 1837))
		  .moveTo(PointOption.point(873, 144))
		  .release()
		  .perform();
        
        Thread.sleep(25000);
        (new TouchAction(driver)).press(PointOption.point(828, 1971))
		  .moveTo(PointOption.point(870, 144))
		  .release()
		  .perform();
        
        Thread.sleep(25000);
        (new TouchAction(driver)).press(PointOption.point(828, 1958))
		  .moveTo(PointOption.point(870, 123))
		  .release()
		  .perform();
        
        
       // buttonClick(TopicObject.getoLanguages());
       // test.log(LogStatus.PASS, "clicked on the languages coures");
        
        Thread.sleep(20000);
//        VerifyelementIsDisplayed(RatingObject.getoCourseRating());
//        test.log(LogStatus.PASS,"Course rating is displayed");
//        
        
	} 
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (74).xlsx", "Sheet1", "feedbackTopiclevelTest");
	}
}

	
	

