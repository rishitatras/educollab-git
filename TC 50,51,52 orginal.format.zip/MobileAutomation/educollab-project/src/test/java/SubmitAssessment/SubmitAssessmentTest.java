package SubmitAssessment;


import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import CourseTopic.CourseTopic;
import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;

	
	
	
	public class SubmitAssessmentTest extends BaseTest {

		SubmitAssessment SubmitObject;  // sprint 50 Aio test case 
		
		@Test(dataProvider="loginData")
		public void ValidCredentials(String email,String password) throws InterruptedException {
			test = extent.startTest("Valid credentials Success Login ").assignCategory("Regression Test");
			SubmitObject = new SubmitAssessment(driver);
			
			Thread.sleep(4000);
			clickOnElement(SubmitObject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Default Login");
			
			VerifyelementIsDisplayed(SubmitObject.getoDefaultLoginHeader());
			test.log(LogStatus.PASS, "Login Header Is Displayed");
			
			VerifyelementIsDisplayed(SubmitObject.getoDefaultPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
			
			VerifyelementIsDisplayed(SubmitObject.getoPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
			Thread.sleep(1000);
			clickOnElement(SubmitObject.getoUserName());
			Thread.sleep(1000);
			sendValuesToElement(SubmitObject.getoUserName(), email);
			test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
			
			Thread.sleep(1000);
			clickOnElement(SubmitObject.getoPassWord());
			Thread.sleep(1000);
			sendValuesToElement(SubmitObject.getoPassWord(),password);
			test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
			
	        Thread.sleep(4000);
			clickOnElement(SubmitObject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Login");
			
			Thread.sleep(5000);
			buttonClick(SubmitObject.getoCoureseButton());
	        test.log(LogStatus.PASS,"clicked on course button");
	        
	        Thread.sleep(4000);
	        buttonClick(SubmitObject.getoLanguages());
	        test.log(LogStatus.PASS, "clicked on the languages coures");
	        
	        Thread.sleep(4000);
	        buttonClick(SubmitObject.getoTopicsAndCurriculum());
	        test.log(LogStatus.PASS,"clicked on topic and curriculum");
	        
	        Thread.sleep(4000);
	        buttonClick(SubmitObject.getooldTopic());
	        Thread.sleep(4000);
	      //  swipe(SubmitObject.getooldTopic());
	        test.log(LogStatus.PASS,"clicked on ol topic");
	        
	        Thread.sleep(5000);
	        buttonClick(SubmitObject.getoAnswer());
	        Thread.sleep(2000);
	        test.log(LogStatus.PASS,"clicked on answer");
	        
	        Thread.sleep(4000);
	        buttonClick(SubmitObject.getoPermissionApp());
	        test.log(LogStatus.PASS,"clicked on permission ");
	        
	        Thread.sleep(4000);
	        buttonClick(SubmitObject.getoNextArrow());
	        test.log(LogStatus.PASS,"clicked on next button");
	        
	        Thread.sleep(4000);
	        buttonClick(SubmitObject.getoPreviousArrow());
	        test.log(LogStatus.PASS,"clicked on previous button");
	        
	        
		}
		
		private String getoUserName() {
			return null;
			// TODO Auto-generated method stub
			//	return null;
		}

		@DataProvider(name="loginData")
		public Object[][] getLoginData() throws IOException{
			return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (5).xlsx", "Sheet1", "SubmitAssessmentTest");
		}
	        
	        
	        
	        
	        
	        
	        
	        
	        
}
