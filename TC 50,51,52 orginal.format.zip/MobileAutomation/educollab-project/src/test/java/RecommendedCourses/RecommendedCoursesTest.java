package RecommendedCourses;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.PointOption;



public class RecommendedCoursesTest extends BaseTest {

	
	RecommendedCourses RecommendedObject;  // sprint 50 Aio test case 234
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify see more Re-design & functionality on Recommended course ").assignCategory("Regression Test");
		RecommendedObject = new RecommendedCourses(driver);
		
		Thread.sleep(12000);
		clickOnElement(RecommendedObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		
		Thread.sleep(5000);
		VerifyelementIsDisplayed(RecommendedObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(RecommendedObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(RecommendedObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(8000);
		//sendValuesToElement(CoursesObject.getoUserName(), email);
		clickOnElement(RecommendedObject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(RecommendedObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(5000);
		clickOnElement(RecommendedObject.getoPassWord());
		Thread.sleep(1000);
		sendValuesToElement(RecommendedObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		Thread.sleep(8000);
		buttonClick(RecommendedObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(RecommendedObject.getOHomeTab());
		test.log(LogStatus.PASS,"clicked on the Home tab");
		
		Thread.sleep(5000);
		//(new TouchAction(driver)).tap(929, 1652).perform();
		//(new TouchAction(driver)).tap(274, 512).perform();
		
		Thread.sleep(5000);
		//tapByCoordinates (RecommendedObject.getOSeemore ()) ;
		PointOption(RecommendedObject.getOSeemore());
		Thread.sleep(1500);
		(new TouchAction(driver)).tap(PointOption.point(933, 1652)).perform();
		//(new TouchAction(driver)).tap(943, 1655).perform();
			test.log(LogStatus.PASS,"clicked on the see more option");
			Thread.sleep(8000);
		
		//buttonClick(RecommendedObject.getOSeemore());
		//test.log(LogStatus.PASS,"clicked on the see more option");
		
		//Thread.sleep(2000);
		//selectOptions(RecommendedObject.getoLanguages());
		//test.log(LogStatus.PASS,"clicked on the course");
		
		
		//clickOnElement(RecommendedObject.getoBackButton());
		//test.log(LogStatus.PASS,"clicked on back button"); 
		
		
	}
	
	
	private String getoUserName() {
		return null;
		//TODO Auto-generated method stub
			//return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (25).xlsx", "Sheet1", "RecommendedCoursesTest");
	
        
        
	   
        
		
		
	}	
		
		
		
		
		
	}	

