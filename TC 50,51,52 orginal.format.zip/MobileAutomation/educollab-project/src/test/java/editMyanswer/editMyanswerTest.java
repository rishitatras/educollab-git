package editMyanswer;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class editMyanswerTest extends BaseTest { // sprint 53 test case AIO test no

	editMyanswer   Myanswerobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String text) throws InterruptedException {
		test = extent.startTest("Valid credentials Success Login ").assignCategory("Regression Test");
		Myanswerobject = new editMyanswer(driver);
		
		Thread.sleep(15000);
		clickOnElement(Myanswerobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(Myanswerobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(Myanswerobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(Myanswerobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(Myanswerobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(Myanswerobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(Myanswerobject.getoPassWord());
		sendValuesToElement(Myanswerobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(5000);
		clickOnElement(Myanswerobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(Myanswerobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
	
		
		Thread.sleep(5000);
		clickOnElement(Myanswerobject.getomeenubar());
		test.log(LogStatus.PASS,"clicked on meenu bar");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(964, 863)).perform();
		
		
		Thread.sleep(5000);
		clickOnElement(Myanswerobject.getoquestion());
		test.log(LogStatus.PASS,"clicked on question");
		
		Thread.sleep(5000);
		clickOnElement(Myanswerobject.getoeditoption());
		test.log(LogStatus.PASS,"clicked on edit answer");
		
		
		Thread.sleep(5000);
		clickOnElement(Myanswerobject.getopermissionicon());
		test.log(LogStatus.PASS,"clicked on permission icon");
		
		
		Thread.sleep(5000);
		clickOnElement(Myanswerobject.getoedittext());
		
		sendValuesToElement(Myanswerobject.getoedittext(),text);
		test.log(LogStatus.PASS,"clicked on edit text");
		
//		Thread.sleep(5000);
//		(new TouchAction(driver)).tap(PointOption.point(782, 2321)).perform();
//		
		
	
		Thread.sleep(5000);
		(new TouchAction(driver)).press(PointOption.point(964, 1234))
		  .moveTo(PointOption.point(982, 161))
		  .release()
		  .perform();
		
		Thread.sleep(5000);
		clickOnElement(Myanswerobject.getosubmitbutton());
		test.log(LogStatus.PASS,"clicked on submit button");
		
	//	Thread.sleep(5000);
		//clickOnElement(Myanswerobject.getoyesbutton());
	//	test.log(LogStatus.PASS,"clicked on yes");
		
	}
	
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (49).xlsx", "Sheet1", "editMyanswerTest");
	}		
		
		
		
	
	}

