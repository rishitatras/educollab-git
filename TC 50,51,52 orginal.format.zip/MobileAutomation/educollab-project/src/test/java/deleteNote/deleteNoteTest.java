package deleteNote;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import notesListing.notesListing;

public class deleteNoteTest extends BaseTest { // sprint 54 test case AIO test no 293

	deleteNote   Noteobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify Delete Note Functionality in Session video").assignCategory("Regression Test");
		Noteobject = new deleteNote(driver);
		
		Thread.sleep(10000);
		clickOnElement(Noteobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(Noteobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(Noteobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(Noteobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(Noteobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(Noteobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(Noteobject.getoPassWord());
		sendValuesToElement(Noteobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(8000);
		clickOnElement(Noteobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(Noteobject.getocoursetab());
		test.log(LogStatus.PASS, "Clicked on coursetab");
		
		Thread.sleep(5000);
		clickOnElement(Noteobject.getolanguage());
		test.log(LogStatus.PASS, "Clicked on languages");
		
		Thread.sleep(5000);
		clickOnElement(Noteobject.getotopic());
		test.log(LogStatus.PASS, "Clicked on topic");
		
		Thread.sleep(5000);
		clickOnElement(Noteobject.getothridtopic());
		test.log(LogStatus.PASS, "Clicked on thirdtopic");
		
		Thread.sleep(5000);
		clickOnElement(Noteobject.getonote());
		
		test.log(LogStatus.PASS, "Clicked on notes");
		
		Thread.sleep(5000);
		clickOnElement(Noteobject.getothreeidot());
		test.log(LogStatus.PASS, "Clicked on three idot");
		
		Thread.sleep(5000);
		clickOnElement(Noteobject.getodeletebutton());
		test.log(LogStatus.PASS, "Clicked on delete button");
		
//		Thread.sleep(5000);
//		clickOnElement(Noteobject.getoyes());
//		test.log(LogStatus.PASS, "Clicked on yes");
//		Thread.sleep(1000);
//		
		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (57).xlsx", "Sheet1", "deleteNoteTest");
	}		
		
		
}


