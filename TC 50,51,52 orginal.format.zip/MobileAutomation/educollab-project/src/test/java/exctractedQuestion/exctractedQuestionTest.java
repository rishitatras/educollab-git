package exctractedQuestion;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import verifyTag.verifyTag;

public class exctractedQuestionTest extends BaseTest { // sprint 57 test case AIO test no 310

	exctractedQuestion   Questionobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify extracted question filter on session level question").assignCategory("Regression Test");
		Questionobject = new exctractedQuestion(driver);
		
		Thread.sleep(10000);
		clickOnElement(Questionobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(Questionobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(Questionobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(Questionobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(Questionobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(Questionobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(Questionobject.getoPassWord());
		sendValuesToElement(Questionobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(10000);
		clickOnElement(Questionobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		clickOnElement(Questionobject.getocoursetab());
		test.log(LogStatus.PASS, "Clicked on coursetab");
		
		Thread.sleep(8000);
		(new TouchAction(driver)).press(PointOption.point(982, 1823))
		  .moveTo(PointOption.point(975, 250))
		  .release()
		  .perform();
		
		
		Thread.sleep(15000);
		clickOnElement(Questionobject.getolanguage());
		test.log(LogStatus.PASS, "Clicked on languages");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getotopic());
		test.log(LogStatus.PASS, "Clicked on topic");
		
		Thread.sleep(8000);
		clickOnElement(Questionobject.getothridtopic());
		test.log(LogStatus.PASS, "Clicked on thirdtopic");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getocomment());
		test.log(LogStatus.PASS, "Clicked on comment tab");
		
		Thread.sleep(1000);
		clickOnElement(Questionobject.getoquestiontab());
		test.log(LogStatus.PASS, "Clicked on question tab");
		
		Thread.sleep(8000);
		(new TouchAction(driver)).tap(PointOption.point(1010, 1273)).perform();
		
		Thread.sleep(8000);
		(new TouchAction(driver)).tap(PointOption.point(123, 403)).perform();
		
	//	Thread.sleep(8000);
	//	(new TouchAction(driver)).tap(PointOption.point(838, 2135)).perform();
		
		
		Thread.sleep(1000);
		clickOnElement(Questionobject.getoapply());
		test.log(LogStatus.PASS, "Clicked on apply tab");
		
		Thread.sleep(3000);
	}
		
		
		
		
		private String getoUserName() {
			return null;
			// TODO Auto-generated method stub
			//	return null;
		}

		@DataProvider(name="loginData")
		public Object[][] getLoginData() throws IOException{
			return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (66).xlsx", "Sheet1", "exctractedQuestionTest");
		}		

	
}


	

