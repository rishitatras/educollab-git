package unsubscribeCourse;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import videoAttachment.videoAttachment;

public class unsubscribeCourseTest extends BaseTest {

	unsubscribeCourse  unsubscribeobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("Valid credentials Success Login ").assignCategory("Regression Test");
		unsubscribeobject = new unsubscribeCourse(driver);
		
		Thread.sleep(15000);
		clickOnElement(unsubscribeobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(unsubscribeobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(unsubscribeobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(unsubscribeobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(4000);
		clickOnElement(unsubscribeobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(unsubscribeobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(4000);
		clickOnElement(unsubscribeobject.getoPassWord());
		sendValuesToElement(unsubscribeobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(4000);
		clickOnElement(unsubscribeobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		
		Thread.sleep(5000);
		(new TouchAction(driver)).press(PointOption.point(820, 792))
		  .moveTo(PointOption.point(790, 20))
		  .release()
		  .perform();
		
		Thread.sleep(8000);
		
		Thread.sleep(4000);
		clickOnElement(unsubscribeobject.getoDrama());
		test.log(LogStatus.PASS, "Clicked on drama");
		Thread.sleep(5000);
		
		Thread.sleep(4000);
		clickOnElement(unsubscribeobject.getoqadrama());
		test.log(LogStatus.PASS, "Clicked on qadrama");
		Thread.sleep(5000);
		
//		Thread.sleep(5000);
//		(new TouchAction(driver)).tap(PointOption.point(929, 1967)).perform();
//		
//		Thread.sleep(5000);
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (37).xlsx", "Sheet1", "unsubscribeCourseTest");
	}
		
		
}
	

