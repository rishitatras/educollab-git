package uploadFile;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class uploadFileTest  extends BaseTest { // sprint 54 test case AIO test no 291

	uploadFile   Fileobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String notesTitle,String enterNotes) throws InterruptedException {
		test = extent.startTest("To verify Upload your resource here functionality in a note ").assignCategory("Regression Test");
		Fileobject = new uploadFile(driver);
		
		Thread.sleep(10000);
		clickOnElement(Fileobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(Fileobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(Fileobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(Fileobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(Fileobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(Fileobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(Fileobject.getoPassWord());
		sendValuesToElement(Fileobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(8000);
		clickOnElement(Fileobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		clickOnElement(Fileobject.getocoursetab());
		test.log(LogStatus.PASS, "Clicked on coursetab");
		
		Thread.sleep(8000);
		clickOnElement(Fileobject.getolanguage());
		test.log(LogStatus.PASS, "Clicked on languages");
		
		Thread.sleep(8000);
		clickOnElement(Fileobject.getotopic());
		test.log(LogStatus.PASS, "Clicked on topic");
		
		Thread.sleep(8000);
		clickOnElement(Fileobject.getothridtopic());
		test.log(LogStatus.PASS, "Clicked on thirdtopic");
		
		Thread.sleep(8000);
		(new TouchAction(driver)).tap(PointOption.point(964, 2125)).perform();
		
		Thread.sleep(8000);
		(new TouchAction(driver)).tap(PointOption.point(943, 1953)).perform();

		
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getopermission());
		test.log(LogStatus.PASS, "Clicked on permission button");
		
		Thread.sleep(8000);
		clickOnElement(Fileobject.getonotetitle());
		Thread.sleep(1000);
		sendValuesToElement(Fileobject.getonotetitle(),notesTitle);
		test.log(LogStatus.PASS, "Clicked on notes title");
		
		Thread.sleep(8000);
		clickOnElement(Fileobject.getoenternote());
		Thread.sleep(1000);
		sendValuesToElement(Fileobject.getoenternote(),enterNotes);
		test.log(LogStatus.PASS, "Clicked on enter note");
		
		
		
		
		Thread.sleep(5000);
		(new TouchAction(driver)).press(PointOption.point(842, 715))//799,684
		  .moveTo(PointOption.point(831, 98)) //844,168
		  .release()
		  .perform();
//		(new TouchAction(driver)).tap(PointOption.point(782, 2314)).perform();
//		Thread.sleep(3000);
//		(new TouchAction(driver)).tap(PointOption.point(835, 2149)).perform();
 
		Thread.sleep(5000);
		clickOnElement(Fileobject.getouploadfile());
		test.log(LogStatus.PASS, "Clicked on uploadfile");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getogallery());
		test.log(LogStatus.PASS, "Clicked on gallery");
		
		Thread.sleep(000);
		clickOnElement(Fileobject.getoallowbutton());
		test.log(LogStatus.PASS, "Clicked on allow button");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getoselectgallery());
		test.log(LogStatus.PASS, "Clicked on select gallery");
		
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto1());
		test.log(LogStatus.PASS, "Clicked on photo1");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto2());
		test.log(LogStatus.PASS, "Clicked on photo2");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto3());
		test.log(LogStatus.PASS, "Clicked on photo3");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto4());
		test.log(LogStatus.PASS, "Clicked on photo4");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto5());
		test.log(LogStatus.PASS, "Clicked on photo5");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto6());
		test.log(LogStatus.PASS, "Clicked on photo6");
				
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto7());
		test.log(LogStatus.PASS, "Clicked on photo7");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto8());
		test.log(LogStatus.PASS, "Clicked on photo8");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto9());
		test.log(LogStatus.PASS, "Clicked on photo9");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getophoto10());
		test.log(LogStatus.PASS, "Clicked on photo10");
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getook());
		test.log(LogStatus.PASS, "Clicked on ok button");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).press(PointOption.point(856, 1999))//799,684
		  .moveTo(PointOption.point(891, 90 )) //844,168
		  .release()
		  .perform();
		
		Thread.sleep(5000);
		clickOnElement(Fileobject.getosubmit());
		test.log(LogStatus.PASS, "Clicked on submit");
		
		Thread.sleep(18000);
		
		
//		Thread.sleep(5000);
//		(new TouchAction(driver)).tap(PointOption.point(894, 2142)).perform();
 Thread.sleep(3000);
 
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (63).xlsx", "Sheet1", "uploadFileTest");
	}					

}

	
	
	

