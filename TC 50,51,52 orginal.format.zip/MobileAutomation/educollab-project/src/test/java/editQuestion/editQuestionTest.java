package editQuestion;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class editQuestionTest extends BaseTest { // sprint 53 test case AIO test no 284

	 editQuestion   Questionobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String question,String coin,String tag) throws InterruptedException {
		test = extent.startTest("To verify Edit Question Functionality ").assignCategory("Regression Test");
		Questionobject = new editQuestion(driver);
		
		Thread.sleep(15000);
		clickOnElement(Questionobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		VerifyelementIsDisplayed(Questionobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(Questionobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(Questionobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(Questionobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(Questionobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(Questionobject.getoPassWord());
		sendValuesToElement(Questionobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(5000);
		clickOnElement(Questionobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
	
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getomeenubar());
		test.log(LogStatus.PASS,"clicked on meenu bar");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(964, 712)).perform();
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getoquestion());
		test.log(LogStatus.PASS,"clicked on question");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getoedit());
		test.log(LogStatus.PASS,"clicked on edit ");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getoquestiontype());
		sendValuesToElement(Questionobject.getoquestiontype(),question);
		test.log(LogStatus.PASS,"clicked on type of question");
		
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getocoin());
		sendValuesToElement(Questionobject.getocoin(),coin);
		test.log(LogStatus.PASS,"clicked on coin");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getotags());
		sendValuesToElement(Questionobject.getotags(),tag);
		test.log(LogStatus.PASS,"clicked on tags");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getoselectcourse());
		test.log(LogStatus.PASS,"clicked on select");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getocomputerscience());
		test.log(LogStatus.PASS,"clicked on computer science");
		
		Thread.sleep(5000);
		clickOnElement(Questionobject.getocategory());
		test.log(LogStatus.PASS,"clicked on category");
		
	//	Thread.sleep(5000);
	//clickOnElement(Questionobject.getocommerce());
//	test.log(LogStatus.PASS,"clicked on commerce");
//		
//		
		Thread.sleep(8000);
		(new TouchAction(driver)).press(PointOption.point(873, 1522))
		  .moveTo(PointOption.point(870, 1041))
		  .release()
		  .perform();
		
	Thread.sleep(5000);
		clickOnElement(Questionobject.getosubmit());
		test.log(LogStatus.PASS,"clicked on submit");
//		
		Thread.sleep(5000);
	}
//	private String getoUserName() {
//		return null;
//		// TODO Auto-generated method stub
		//	return null;
	

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (50).xlsx", "Sheet1", "editQuestionTest");
	}		

	
	
}
