package DetailedQuestion;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import questionscreen.questionscreen;

public class DetailedQuestionTest extends BaseTest {

	
	DetailedQuestion QuestionObject;  // sprint 51 Aio test case 256 
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify Detailed Question view screen ").assignCategory("Regression Test");
		QuestionObject = new DetailedQuestion(driver);
		
		Thread.sleep(10000);
		clickOnElement(QuestionObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		
		VerifyelementIsDisplayed(QuestionObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(QuestionObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(QuestionObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(8000);
		clickOnElement(QuestionObject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(QuestionObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(8000);
		clickOnElement(QuestionObject.getoPassWord());
		sendValuesToElement(QuestionObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(10000);
		clickOnElement(QuestionObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(6000);
		clickOnElement(QuestionObject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
		Thread.sleep(3000);
		
//		clickOnElement(QuestionObject.getodetailquestion());
//		test.log(LogStatus.PASS,"clicked on detail ques");
//		Thread.sleep(3000);
//		
	
}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (7).xlsx", "Sheet1", "DetailedQuestionTest");
	}	
}
		