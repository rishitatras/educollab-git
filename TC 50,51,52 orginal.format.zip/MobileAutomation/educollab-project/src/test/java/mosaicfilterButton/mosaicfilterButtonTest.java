package mosaicfilterButton;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;


public class mosaicfilterButtonTest extends BaseTest{


	
	mosaicfilterButton  button;  // sprint 50 Aio test case 300
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify filter icon on mosaic home page ").assignCategory("Regression Test");
		button = new mosaicfilterButton(driver);
		Thread.sleep(10000);
		
		clickOnElement(button.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(button.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(button.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(button.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(8000);
		clickOnElement(button.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(button.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		clickOnElement(button.getoPassWord());
		Thread.sleep(1000);
		sendValuesToElement(button.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		Thread.sleep(8000);
		clickOnElement(button.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		buttonClick(button.getOMeenubar());
		test.log(LogStatus.PASS,"clicked on the meenu bar");
		Thread.sleep(1000);
		
		(new TouchAction(driver)).tap(PointOption.point(123, 806)).perform();
		
		Thread.sleep(10000);

		
		buttonClick(button.getofiltericon());
		test.log(LogStatus.PASS,"clicked on filter icon");
		Thread.sleep(3000);
	
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (70).xlsx", "Sheet1", "mosaicfilterButtonTest");
	}

	

	
	
}
