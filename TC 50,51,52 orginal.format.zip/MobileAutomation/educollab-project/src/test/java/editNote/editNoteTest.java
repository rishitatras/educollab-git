package editNote;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class editNoteTest extends BaseTest { // sprint 54 test case AIO test no 292

	editNote   editobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String text) throws InterruptedException {
		test = extent.startTest("To verify Edite Note functionality in session video").assignCategory("Regression Test");
		editobject = new editNote(driver);
		
		Thread.sleep(10000);
		clickOnElement(editobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(editobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(editobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(editobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(editobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(editobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(editobject.getoPassWord());
		sendValuesToElement(editobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(8000);
		clickOnElement(editobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(editobject.getocoursetab());
		test.log(LogStatus.PASS, "Clicked on coursetab");
		
		Thread.sleep(8000);
		(new TouchAction(driver)).press(PointOption.point(982, 1823))
		  .moveTo(PointOption.point(975, 250))
		  .release()
		  .perform();
		
		Thread.sleep(10000);
		clickOnElement(editobject.getolanguage());
		test.log(LogStatus.PASS, "Clicked on languages");
		
		Thread.sleep(8000);
		clickOnElement(editobject.getotopic());
		test.log(LogStatus.PASS, "Clicked on topic");
		
		Thread.sleep(10000);
		clickOnElement(editobject.getothridtopic());
		test.log(LogStatus.PASS, "Clicked on thirdtopic");
		
		Thread.sleep(15000);
		clickOnElement(editobject.getonote());
		
		test.log(LogStatus.PASS, "Clicked on notes");
		
		Thread.sleep(8000);
		clickOnElement(editobject.getothreeidot());
		test.log(LogStatus.PASS, "Clicked on three idot");
		
		Thread.sleep(5000);
		clickOnElement(editobject.getoedit());
		test.log(LogStatus.PASS, "Clicked on edit note");
		
		Thread.sleep(8000);
		clickOnElement(editobject.getopermission());
		test.log(LogStatus.PASS, "Clicked on permission button ");
		
//		Thread.sleep(5000);
//		clickOnElement(editobject.getotext());
//		Thread.sleep(1000);
//		sendValuesToElement(editobject.getotext(),text);
//		test.log(LogStatus.PASS, "Clicked on enter text");
//		
//		Thread.sleep(5000);
//		(new TouchAction(driver)).press(PointOption.point(842, 715))//799,684
//		  .moveTo(PointOption.point(831, 98)) //844,168
//		  .release()
//		  .perform();
//		
//		Thread.sleep(5000);
//	(new TouchAction(driver)).tap(PointOption.point(782, 2318)).perform();
//		
		Thread.sleep(8000);
		clickOnElement(editobject.getouploadfile());
		test.log(LogStatus.PASS, "Clicked on uploadfile");
		
		Thread.sleep(8000);
		clickOnElement(editobject.getogallery());
		test.log(LogStatus.PASS, "Clicked on gallery");
		
		Thread.sleep(5000);
		clickOnElement(editobject.getoallowbutton());
		test.log(LogStatus.PASS, "Clicked on allow button");
		
		Thread.sleep(5000);
		clickOnElement(editobject.getoselectgallery());
		test.log(LogStatus.PASS, "Clicked on select gallery ");
		
		Thread.sleep(5000);
		clickOnElement(editobject.getoselectphoto());
		test.log(LogStatus.PASS, "Clicked on select photo");
		
		Thread.sleep(5000);
		clickOnElement(editobject.getookbutton());
		test.log(LogStatus.PASS, "Clicked on ok button");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).press(PointOption.point(803, 642))//799,684
	  .moveTo(PointOption.point(806, 284)) //844,168
		  .release()
		  .perform();
		
		
		//Thread.sleep(5000);
		//clickOnElement(editobject.getoupdate());
		//test.log(LogStatus.PASS, "Clicked on update button");
		
		Thread.sleep(5000);
		
		
		
		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (59).xlsx", "Sheet1", "editNoteTest");
	}			
		

}
