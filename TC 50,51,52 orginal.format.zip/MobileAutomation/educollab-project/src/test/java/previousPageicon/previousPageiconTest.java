package previousPageicon;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import nextPageicon.nextPageicon;

public class previousPageiconTest extends BaseTest {

	previousPageicon previoustObject;  // sprint 61 Aio test case 
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify arrow icon < for previous page on answer assessment screen").assignCategory("Regression Test");
		previoustObject = new 	previousPageicon (driver);
		
		Thread.sleep(4000);
		clickOnElement(previoustObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		
		VerifyelementIsDisplayed(previoustObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(previoustObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(previoustObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(2000);
		//sendValuesToElement(CoursesObject.getoUserName(), email);
		clickOnElement(previoustObject.getoUserName());
		Thread.sleep(500);
		sendValuesToElement(previoustObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(500);
		clickOnElement(previoustObject.getoPassWord());
		sendValuesToElement(previoustObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		Thread.sleep(4000);
		buttonClick(previoustObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		clickOnElement(previoustObject.getoCoureseButton());
		test.log(LogStatus.PASS,"clicked on the CoureseButton ");
		
		Thread.sleep(8000);
		(new TouchAction(driver)).press(PointOption.point(982, 1823))
		  .moveTo(PointOption.point(975, 250))
		  .release()
		  .perform();
		
		Thread.sleep(8000);
		clickOnElement(previoustObject.getolanguage());
		test.log(LogStatus.PASS,"clicked on the language ");
		
		
		Thread.sleep(8000);
		clickOnElement(previoustObject.getocourseresources());
		test.log(LogStatus.PASS,"clicked on the courseresource ");
		
		Thread.sleep(8000);
		clickOnElement(previoustObject.getoinstructor());
		test.log(LogStatus.PASS,"clicked on the instructor ");
		
		Thread.sleep(8000);
		clickOnElement(previoustObject.getolivesession());
		test.log(LogStatus.PASS,"clicked on the livesession ");
		
		Thread.sleep(8000);
		clickOnElement(previoustObject.getoassessmenttab());
		test.log(LogStatus.PASS,"clicked on the assessmenttab ");
		
		Thread.sleep(8000);
		clickOnElement(previoustObject.getoanswerbutton());
		test.log(LogStatus.PASS,"clicked on the answer button");
		
		
		
		Thread.sleep(8000);
		(new TouchAction(driver)).tap(PointOption.point(558, 1504)).perform();
		test.log(LogStatus.PASS,"clicked on the permission button");
		
		
		
		
		Thread.sleep(4000);
		clickOnElement(previoustObject.getonextpage());
		test.log(LogStatus.PASS,"clicked on the next page");
		
		
		
		Thread.sleep(4000);
		clickOnElement(previoustObject.getopreviouspage());
		test.log(LogStatus.PASS,"clicked on the previous page");
		
		Thread.sleep(3000);
//		.press(PointOption.point(817, 1627}))
//		  .moveTo(PointOption.point(814, 179}))
//		  .release()
//		  .perform();
//	
//		Thread.sleep(10000);
//		PointOption(FeaturedObject.getoFeaturedCourse());
//		test.log(LogStatus.PASS,"clicked on course");
		

}
	
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (77).xlsx", "Sheet1", "previousPageiconTest");
	}

	
	


}
