package filterButton;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;

public class filterButtonTest extends BaseTest { // sprint 53 test case AIO test no 280 

	filterButton   filterobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify filter button in the question tab ").assignCategory("Regression Test");
		filterobject = new filterButton(driver);
		
		Thread.sleep(15000);
		clickOnElement(filterobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		VerifyelementIsDisplayed(filterobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(filterobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(filterobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(filterobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(filterobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(filterobject.getoPassWord());
		sendValuesToElement(filterobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(10000);
		clickOnElement(filterobject.getoLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		clickOnElement(filterobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
		
		Thread.sleep(5000);
		clickOnElement(filterobject.getofiltericon());
		test.log(LogStatus.PASS, "Clicked on filtericon");
		
		Thread.sleep(5000);
		clickOnElement(filterobject.getorecentquestion());
		test.log(LogStatus.PASS, "Clicked on recentquestion");
		
		Thread.sleep(5000);
		clickOnElement(filterobject.getoApply1());
		test.log(LogStatus.PASS, "Clicked on apply");
		
		Thread.sleep(5000);
		clickOnElement(filterobject.getofilteriocon1());
		test.log(LogStatus.PASS, "Clicked on filter icon1");
		
		Thread.sleep(5000);
		clickOnElement(filterobject.getomostvisted());
		test.log(LogStatus.PASS, "Clicked on most visted");
		
		Thread.sleep(5000);
		clickOnElement(filterobject.getoApply2());
		test.log(LogStatus.PASS, "Clicked on apply1");
		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (40).xlsx", "Sheet1", "filterButtonTest");
	}	
		
		
		
	}
	

	

