package AskQuestion;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import globalsearch.globalsearch;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class AskQuestionTest extends BaseTest {

	AskQuestion   askobject;    // sprint 51 test case 250 
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String text,String coin,String tag) throws InterruptedException {
		test = extent.startTest("To verify Ask question screen & functionality without attachment ").assignCategory("Regression Test");
		askobject = new AskQuestion(driver);
		
		Thread.sleep(8000);
		clickOnElement(askobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		
		Thread.sleep(5000);
		VerifyelementIsDisplayed(askobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(askobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(askobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(4000);
		clickOnElement(askobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(askobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(4000);
		clickOnElement(askobject.getoPassWord());
		sendValuesToElement(askobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(4000);
		clickOnElement(askobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(askobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
		Thread.sleep(3000);



Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(961, 1971)).perform();
		
		Thread.sleep(5000);
		clickOnElement(askobject.getotext());
		sendValuesToElement(askobject.getotext(),text);
		test.log(LogStatus.PASS,"enter the text");
		
		Thread.sleep(5000);
		clickOnElement(askobject.getocoin());
		sendValuesToElement(askobject.getocoin(),coin);
		test.log(LogStatus.PASS,"enterthe coins");
		
		Thread.sleep(5000);
		clickOnElement(askobject.getotag());
		sendValuesToElement(askobject.getotag(),tag);
		test.log(LogStatus.PASS," enter the tag");
		
		Thread.sleep(5000);
		clickOnElement(askobject.getocoursetag());
		test.log(LogStatus.PASS," enter the course tag");
		
		
		
		
		
		Thread.sleep(5000);
		clickOnElement(askobject.getocategories());
		test.log(LogStatus.PASS,"enter the catory");
		
		Thread.sleep(8000);
		clickOnElement(askobject.getoselectcategory());
		test.log(LogStatus.PASS,"enter the select catory");
		
		Thread.sleep(8000);
		
		(new TouchAction(driver)).press(PointOption.point(898, 1434))
		  .moveTo(PointOption.point(898, 792))
		  .release()
		  .perform();
		
		
		
		Thread.sleep(8000);

		clickOnElement(askobject.getosubmit());
		test.log(LogStatus.PASS,"enter the submit");
		
		Thread.sleep(10000);
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (13).xlsx", "Sheet1", "AskQuestionTest");
	}
		
		
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	

