package EduCollab.MobileAutomation.Login;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.LoginPage.libraries.LoginPageObjects;
import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;

public class LoginTest extends BaseTest {
	LoginPageObjects loginObject;

	@Test(dataProvider="loginData")
	public void BothMandatoryFieldsMissingError(String email,String password) throws InterruptedException {
		test = extent.startTest("Login page - Mandatory Fields Missing Error test ").assignCategory("Regression Test");
		
		loginObject = new LoginPageObjects(driver);
		Thread.sleep(3000);
		clickOnElement(loginObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(loginObject.getoLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(loginObject.getoEnterYourEmailAddressText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(loginObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		sendValuesToElement(loginObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		sendValuesToElement(loginObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		clickOnElement(loginObject.getOLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		VerifyelementIsDisplayed(loginObject.getoMandatoryFieldMissingUserName());
		test.log(LogStatus.PASS, "Mandatory Field Username Missing is displayed ");
		
		VerifyelementIsDisplayed(loginObject.getoMandatoryFieldMissingPassword());
		test.log(LogStatus.PASS, "Mandatory Field Password Missing is displayed ");
	}

	@Test(dataProvider="loginData")
	public void EmailMandatoryFieldsMissingError(String email,String password) throws InterruptedException {
		test = extent.startTest("Login page - Email Mandatory Field Missing Error test ")
				.assignCategory("Regression Test");
		loginObject = new LoginPageObjects(driver);
		Thread.sleep(1000);
		clickOnElement(loginObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(loginObject.getoLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(loginObject.getoEnterYourEmailAddressText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(loginObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		sendValuesToElement(loginObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		clickOnElement(loginObject.getOLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		VerifyelementIsDisplayed(loginObject.getoMandatoryFieldMissingUserName());
		test.log(LogStatus.PASS, "Mandatory Field Username Missing is displayed ");
	}

	@Test(dataProvider="loginData",enabled=false)
	public void PasswordMandatoryFieldsMissingError(String email,String password) throws InterruptedException {
		test = extent.startTest("Login page - Password Mandatory Fields Missing Error test ")
				.assignCategory("Regression Test");
		loginObject = new LoginPageObjects(driver);
		Thread.sleep(1000);
		clickOnElement(loginObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(loginObject.getoLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(loginObject.getoEnterYourEmailAddressText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(loginObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		sendValuesToElement(loginObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		clickOnElement(loginObject.getOLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		VerifyelementIsDisplayed(loginObject.getoMandatoryFieldMissingPassword());
		test.log(LogStatus.PASS, "Mandatory Field Password Missing is displayed ");
	}

	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("Valid credentials Success Login ").assignCategory("Regression Test");
		loginObject = new LoginPageObjects(driver);
		Thread.sleep(1000);
		clickOnElement(loginObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(loginObject.getoLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(loginObject.getoEnterYourEmailAddressText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(loginObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		sendValuesToElement(loginObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		sendValuesToElement(loginObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		clickOnElement(loginObject.getOLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
	}

	@Test(dataProvider="loginData",enabled = false)
	public void InValidCredentialsPassword(String email,String password) throws InterruptedException {
		test = extent.startTest("Login page -Innvalid Password Message Validation test ")
				.assignCategory("Regression Test");
		loginObject = new LoginPageObjects(driver);
		Thread.sleep(1000);
		clickOnElement(loginObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(loginObject.getoLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(loginObject.getoEnterYourEmailAddressText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(loginObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		sendValuesToElement(loginObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		sendValuesToElement(loginObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		clickOnElement(loginObject.getOLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		// loginObject.getoErrorPasswordNotValid().isDisplayed();
	}

	@Test(dataProvider="loginData")
	public void InValidCredentialsTest(String email,String password) throws InterruptedException {
		test = extent.startTest("Login page - Invalid Credentials Test").assignCategory("Regression Test");
		loginObject = new LoginPageObjects(driver);
		Thread.sleep(1000);
		clickOnElement(loginObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(loginObject.getoLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(loginObject.getoEnterYourEmailAddressText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(loginObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		sendValuesToElement(loginObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		sendValuesToElement(loginObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		clickOnElement(loginObject.getOLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		// loginObject.getOInvalidUserNameAndPasswordPrompt().isDisplayed();

	}

	@Test(dataProvider="loginData",enabled=false)
	public void ForgotPasswordLink(String email,String password) throws InterruptedException {
		test = extent.startTest("Login page - Forgot Password Link test ").assignCategory("Regression Test");
		loginObject = new LoginPageObjects(driver);
		Thread.sleep(1000);
		clickOnElement(loginObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(loginObject.getoLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(loginObject.getoEnterYourEmailAddressText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(loginObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(loginObject.getOforgotPasswordLink());
		test.log(LogStatus.PASS, "Forgot Password Link is present");
		
		clickOnElement(loginObject.getOforgotPasswordLink());
		test.log(LogStatus.PASS, "Clicked on Forgot password");
	}

	@Test(dataProvider="loginData")
	public void logOut(String email,String password) throws InterruptedException {
		test = extent.startTest("HomePage - Logout test ").assignCategory("Regression Test");
		loginObject = new LoginPageObjects(driver);
		Thread.sleep(1000);
		clickOnElement(loginObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(loginObject.getoLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(loginObject.getoEnterYourEmailAddressText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(loginObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		sendValuesToElement(loginObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		sendValuesToElement(loginObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		clickOnElement(loginObject.getOLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		System.out.println("Logged In");
		assertTrue(false);
	}
	
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet.xlsx", "LoginPage", "LoginTest");
	}
}
