package videoAttachement;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import videoAttachment.videoAttachment;


public class videoAttachementTest extends BaseTest {

	videoAttachment   videoobject;  // sprint 52 Aio test case 263
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String text,String coin,String tag) throws InterruptedException {
		test = extent.startTest("To verify ").assignCategory("Regression Test");
		videoobject = new videoAttachment(driver);
		
		Thread.sleep(15000);
		clickOnElement(videoobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(videoobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(videoobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(videoobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(4000);
		clickOnElement(videoobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(videoobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(4000);
		clickOnElement(videoobject.getoPassWord());
		sendValuesToElement(videoobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(4000);
		clickOnElement(videoobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(12000);
		clickOnElement(videoobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
		Thread.sleep(3000);


		(new TouchAction(driver)).tap(PointOption.point(961, 1971)).perform();
		
		Thread.sleep(5000);
		clickOnElement(videoobject.getotext());
		sendValuesToElement(videoobject.getotext(),text);
		test.log(LogStatus.PASS,"enter the text");
		
		Thread.sleep(5000);
		clickOnElement(videoobject.getocoin());
		sendValuesToElement(videoobject.getocoin(),coin);
		test.log(LogStatus.PASS,"enterthe coins");
		
		Thread.sleep(5000);
		clickOnElement(videoobject.getoquestiiontag());
		sendValuesToElement(videoobject.getoquestiiontag(),tag);
		test.log(LogStatus.PASS,"enterthe tag");
		
		Thread.sleep(5000);
		clickOnElement(videoobject.getotagcategories());
		test.log(LogStatus.PASS,"enterthe categories");
		
		Thread.sleep(5000);
		clickOnElement(videoobject.getocategories());
		test.log(LogStatus.PASS,"enter the catory");
		
		Thread.sleep(5000);
		clickOnElement(videoobject.getoselectcategory());
		test.log(LogStatus.PASS,"enter the select catory");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(828, 1939)).perform();

		Thread.sleep(5000);
		clickOnElement(videoobject.getouploadfile());
		test.log(LogStatus.PASS,"enter the select uploadfile");
		
		Thread.sleep(5000);
		clickOnElement(videoobject.getovideo());
		test.log(LogStatus.PASS,"enter the select photo");
		
		Thread.sleep(5000);
		clickOnElement(videoobject.getovideoselect());
		test.log(LogStatus.PASS,"enter the photo");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(821, 2149)).perform();
		
//		test.log(LogStatus.PASS,"enter the submit");
		Thread.sleep(10000);
		
		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (35).xlsx", "Sheet1", "videoAttachementTest");
	}
		
}	

		
 

	

