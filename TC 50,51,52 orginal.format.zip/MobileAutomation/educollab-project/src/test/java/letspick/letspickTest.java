package letspick;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class letspickTest extends BaseTest {

	
	letspick letsObject;   // sprint 50 Aio test case 238
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify re-design Let's pick where we left  ").assignCategory("Regression Test");
		letsObject = new 	letspick(driver);
		
		Thread.sleep(4000);
		clickOnElement(letsObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(letsObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(letsObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(letsObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(2000);
		//sendValuesToElement(CoursesObject.getoUserName(), email);
		clickOnElement(letsObject.getoUserName());
		Thread.sleep(500);
		sendValuesToElement(letsObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(500);
		clickOnElement(letsObject.getoPassWord());
		sendValuesToElement(letsObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		Thread.sleep(4000);
		buttonClick(letsObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(letsObject.getOHomeTab());
		test.log(LogStatus.PASS,"clicked on the Home tab");
		
		Thread.sleep(5000);
		clickOnElement(letsObject.getOletspick());
		
		
//		(new TouchAction(driver)).press(PointOption.point(996, 1034))
//		  .moveTo(PointOption.point(140, 1059))
//		  .release()
//		  .perform();
		Thread.sleep(8000);
		clickOnElement(letsObject.getOcourse1());
		test.log(LogStatus.PASS,"clicked on course1");
		Thread.sleep(5000);
		
//		clickOnElement(letsObject.getOcourse2());
//		test.log(LogStatus.PASS,"clicked on course2");
//		Thread.sleep(5000);
//		
//		clickOnElement(letsObject.getOOcourse3());
//		test.log(LogStatus.PASS,"clicked on course3");
//		Thread.sleep(5000);
//		
//		
	}
	private String getoUserName() {
		return null;
		//TODO Auto-generated method stub
			//return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (16).xlsx", "Sheet1", "letspickTest");
	}
	
	
	
}
