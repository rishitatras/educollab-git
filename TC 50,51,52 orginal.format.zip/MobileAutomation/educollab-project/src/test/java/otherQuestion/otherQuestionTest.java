package otherQuestion;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import exctractedQuestion.exctractedQuestion;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class otherQuestionTest extends BaseTest { // sprint 57 test case AIO test no 310

	otherQuestion   otherobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify extracted question filter on session level question").assignCategory("Regression Test");
		otherobject = new otherQuestion(driver);
		
		Thread.sleep(10000);
		clickOnElement(otherobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(otherobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(otherobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(otherobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(otherobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(otherobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(otherobject.getoPassWord());
		sendValuesToElement(otherobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(10000);
		clickOnElement(otherobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		clickOnElement(otherobject.getocoursetab());
		test.log(LogStatus.PASS, "Clicked on coursetab");
		
		Thread.sleep(8000);
		(new TouchAction(driver)).press(PointOption.point(982, 1823))
		  .moveTo(PointOption.point(975, 250))
		  .release()
		  .perform();
		
		
		Thread.sleep(15000);
		clickOnElement(otherobject.getolanguage());
		test.log(LogStatus.PASS, "Clicked on languages");
		
		Thread.sleep(5000);
		clickOnElement(otherobject.getotopic());
		test.log(LogStatus.PASS, "Clicked on topic");
		
		Thread.sleep(8000);
		clickOnElement(otherobject.getothridtopic());
		test.log(LogStatus.PASS, "Clicked on thirdtopic");
		
		Thread.sleep(5000);
		clickOnElement(otherobject.getocomment());
		test.log(LogStatus.PASS, "Clicked on comment tab");
		
		Thread.sleep(1000);
		clickOnElement(otherobject.getoquestiontab());
		test.log(LogStatus.PASS, "Clicked on question tab");
		
		Thread.sleep(8000);
		(new TouchAction(driver)).tap(PointOption.point(1010, 1273)).perform();
		
		Thread.sleep(8000);
		(new TouchAction(driver)).tap(PointOption.point(123, 666)).perform();
		
	//	Thread.sleep(8000);
	//	(new TouchAction(driver)).tap(PointOption.point(838, 2135)).perform();
		
		
		Thread.sleep(5000);
		clickOnElement(otherobject.getoapply());
		test.log(LogStatus.PASS, "Clicked on apply tab");
		
		Thread.sleep(5000);
	}
		
		
		
		
		private String getoUserName() {
			return null;
			// TODO Auto-generated method stub
			//	return null;
		}

		@DataProvider(name="loginData")
		public Object[][] getLoginData() throws IOException{
			return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (66).xlsx", "Sheet1", "otherQuestionTest");
		}		

	
}



