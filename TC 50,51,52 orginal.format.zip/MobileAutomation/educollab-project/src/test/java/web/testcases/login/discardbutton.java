package web.testcases.login;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseClass;
import EduCollab.Mobile.utilities.JavaFunctions;
import EduCollab.Web.utilities.BaseTest;
import web.loginPage.discardbuttonObject;

public class discardbutton extends BaseTest {

	BaseClass b=new BaseClass();      // EC-TC 349
	
	
	
	@Test(dataProvider="loginData")
	public void ValidUserNameValidPass(String email, String pass,String coins,String questiontag,String question) throws InterruptedException {
		discardbuttonObject lp = new discardbuttonObject(webDriver);
		test = extent.startTest("Verify the discard button functionality in case of ask a question").assignCategory("Regression Test");
		
		clickOnElement(lp.login());
		Thread.sleep(5000);
		test.log(LogStatus.PASS, "clicked on user");
		
		sendValuesToElement(lp.email(), email);
		Thread.sleep(2000);
		sendValuesToElement(lp.password(), pass);
		Thread.sleep(2000);
		
		clickOnElement(lp.loginicon());
		test.log(LogStatus.PASS, "clicked on login icon");
		
		Thread.sleep(8000);
		clickOnElement(lp.studentcorner());
		test.log(LogStatus.PASS, "clicked on student corner");
		
		Thread.sleep(5000);
		clickOnElement(lp.myquestion());
		test.log(LogStatus.PASS, "clicked on my question");
		
		Thread.sleep(5000);
		clickOnElement(lp.askquestion());
		test.log(LogStatus.PASS, "clicked on  ask question");
		
		Thread.sleep(5000);
		//clickOnElement(lp.category());
		test.log(LogStatus.PASS, "clicked on category ");
		
		b.selectionByIndex(lp.category(), 3);
		test.log(LogStatus.PASS, "category selected ");
		
		Thread.sleep(5000);
		clickOnElement(lp.coins());
		Thread.sleep(5000);
		sendValuesToElement(lp.coins(), coins);		
		test.log(LogStatus.PASS, "clicked on coins ");
		
		Thread.sleep(5000);
		clickOnElement(lp.questiontag());
		Thread.sleep(5000);
		sendValuesToElement(lp.questiontag(), questiontag);		
		test.log(LogStatus.PASS, "clicked on questiontag ");
		
		Thread.sleep(5000);
		clickOnElement(lp.question());
		Thread.sleep(5000);
		sendValuesToElement(lp.question(), question);		
		test.log(LogStatus.PASS, "clicked on question ");
		

		Thread.sleep(5000);
        JavascriptExecutor  jse = (JavascriptExecutor) webDriver;
		
		
		jse.executeScript("window.scrollBy(0,280)");
		
		
		Thread.sleep(5000);
		b.sendValuesToElement(lp.file(),"C:\\Users\\RISHIKANDHAN\\Pictures\\sample.jpg");
		test.log(LogStatus.PASS, " file selected  ");
		
		Thread.sleep(10000);
		clickOnElement(lp.discard());
		test.log(LogStatus.PASS, "clicked on discard  ");
		
		
		
		
		//clickOnElement(lp.saveBtn());
		//test.log(LogStatus.PASS, "clicked on save  ");
		
		Thread.sleep(8000);
	}
		
		
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"\\data\\EduDataSheet (87).xlsx", "Sheet1", "discardbutton");
	}
}

	
	

