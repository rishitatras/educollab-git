package web.testcases.login;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.JavaFunctions;
import EduCollab.Web.utilities.BaseTest;
import web.loginPage.answercountObject;

public class answercount extends BaseTest {

	@Test(dataProvider="loginData")
	public void ValidUserNameValidPass(String email, String pass) throws InterruptedException {
		answercountObject lp = new answercountObject(webDriver);
		test = extent.startTest("To verify the functionality of count at Answers Given").assignCategory("Regression Test");
		
		clickOnElement(lp.login());
		Thread.sleep(5000);
		test.log(LogStatus.PASS, "clicked on user");
		
		sendValuesToElement(lp.email(), email);
		Thread.sleep(2000);
		sendValuesToElement(lp.password(), pass);
		Thread.sleep(2000);
		
		clickOnElement(lp.loginicon());
		test.log(LogStatus.PASS, "clicked on login icon");
		
		Thread.sleep(8000);
		clickOnElement(lp.studentcorner());
		test.log(LogStatus.PASS, "clicked on student corner");
		
		Thread.sleep(5000);
		clickOnElement(lp.questionlist());
		test.log(LogStatus.PASS, "clicked on question list");
		
		Thread.sleep(5000);
        JavascriptExecutor  jse = (JavascriptExecutor) webDriver;
		
		
		jse.executeScript("window.scrollBy(0,500)");
		
		Thread.sleep(5000);
		clickOnElement(lp.count());
		test.log(LogStatus.PASS, "clicked on count answer");
		
		Thread.sleep(5000);
		
		
		
	}
		
		
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"\\data\\EduDataSheet (83).xlsx", "Sheet1", "answercount");
	}
}


