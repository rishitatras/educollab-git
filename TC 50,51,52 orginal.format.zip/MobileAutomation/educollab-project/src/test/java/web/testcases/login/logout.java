package web.testcases.login;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.JavaFunctions;
import EduCollab.Web.utilities.BaseTest;
import web.loginPage.logoutObjects;

public class logout  extends BaseTest {

	@Test(dataProvider="loginData")
	public void ValidUserNameValidPass(String email, String pass) throws InterruptedException {
		logoutObjects lp = new logoutObjects(webDriver);
		test = extent.startTest("To verify logout functionality with vaild credentials").assignCategory("Regression Test");
		
		clickOnElement(lp.login());
		Thread.sleep(8000);
		test.log(LogStatus.PASS, "clicked on user");
		
		sendValuesToElement(lp.email(), email);
		Thread.sleep(3000);
		sendValuesToElement(lp.password(), pass);
		Thread.sleep(3000);
		
		clickOnElement(lp.loginicon());
		test.log(LogStatus.PASS, "clicked on login icon");
		Thread.sleep(5000);
		
		clickOnElement(lp.logouticon());
		test.log(LogStatus.PASS, "clicked on logout icon");
		
		
		Thread.sleep(5000);
		clickOnElement(lp.logoutbutn());
		test.log(LogStatus.PASS, "clicked on logout icon");
		
		Thread.sleep(3000);
	}
	
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"\\data\\EduDataSheet (17).xlsx", "Sheet1", "loginTest");
	}
}



