package web.testcases.login;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.JavaFunctions;
import EduCollab.Web.utilities.BaseTest;
import web.loginPage.courseclassObject;

public class courseclass extends BaseTest {

	@Test(dataProvider="loginData")
	public void ValidUserNameValidPass(String email, String pass) throws InterruptedException {
		courseclassObject lp = new courseclassObject(webDriver);
		test = extent.startTest("To verify login functionality with vaild credentials").assignCategory("Regression Test");
		
		clickOnElement(lp.login());
		Thread.sleep(3000);
		test.log(LogStatus.PASS, "clicked on user");
		
		sendValuesToElement(lp.email(), email);
		Thread.sleep(2000);
		sendValuesToElement(lp.password(), pass);
		Thread.sleep(2000);
		
		clickOnElement(lp.loginicon());
		test.log(LogStatus.PASS, "clicked on login icon");
		
		Thread.sleep(12000);
		clickOnElement(lp.createcourse());
		test.log(LogStatus.PASS, "clicked on create course");

		Thread.sleep(12000);

		clickOnElement(lp.coursetype());
		test.log(LogStatus.PASS, "clicked on course type");

		Thread.sleep(12000);

	}
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"\\data\\EduDataSheet (79).xlsx", "Sheet1", "courseclass");
	}
	
	
}
