package web.testcases.login;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.JavaFunctions;
import EduCollab.Web.utilities.BaseTest;
import web.loginPage.editcourseObject;

public class editcourse extends BaseTest {

	@Test(dataProvider="loginData")
	public void ValidUserNameValidPass(String email, String pass) throws InterruptedException {
		editcourseObject lp = new editcourseObject(webDriver);
		test = extent.startTest("To verify login functionality with vaild credentials").assignCategory("Regression Test");
		
		clickOnElement(lp.login());
		Thread.sleep(5000);
		test.log(LogStatus.PASS, "clicked on user");
		
		sendValuesToElement(lp.email(), email);
		Thread.sleep(2000);
		sendValuesToElement(lp.password(), pass);
		Thread.sleep(2000);
		
		clickOnElement(lp.loginicon());
		test.log(LogStatus.PASS, "clicked on login icon");
		
		Thread.sleep(5000);
		clickOnElement(lp.mycourse());
		test.log(LogStatus.PASS, "clicked on my course");
		
		Thread.sleep(3000);
		clickOnElement(lp.publishcourse());
		test.log(LogStatus.PASS, "clicked on publish course");
		
		//scroll down and scroll up using pixels
		Thread.sleep(5000);
        JavascriptExecutor  jse = (JavascriptExecutor) webDriver;
				
		jse.executeScript("window.scrollBy(0,500)");
		
		Thread.sleep(5000);
		clickOnElement(lp.edit());
		test.log(LogStatus.PASS, "clicked on edit option");
		

		Thread.sleep(5000);
	}
		
		
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"\\data\\EduDataSheet (80).xlsx", "Sheet1", "editcourse");
	}



}
