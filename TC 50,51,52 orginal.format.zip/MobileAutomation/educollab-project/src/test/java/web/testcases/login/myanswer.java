package web.testcases.login;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseClass;
import EduCollab.Mobile.utilities.JavaFunctions;
import EduCollab.Web.utilities.BaseTest;
import web.loginPage.myanswserObject;

public class myanswer extends BaseTest {

	BaseClass b=new BaseClass();      // EC-TC 349
	
	
	
	@Test(dataProvider="loginData")
	public void ValidUserNameValidPass(String email, String pass,String text) throws InterruptedException {
		myanswserObject lp = new myanswserObject(webDriver);
		test = extent.startTest("Verify the discard button functionality in case of ask a question").assignCategory("Regression Test");
		
		clickOnElement(lp.login());
		Thread.sleep(5000);
		test.log(LogStatus.PASS, "clicked on user");
		
		sendValuesToElement(lp.email(), email);
		Thread.sleep(2000);
		sendValuesToElement(lp.password(), pass);
		Thread.sleep(2000);
		
		clickOnElement(lp.loginicon());
		test.log(LogStatus.PASS, "clicked on login icon");
		
		Thread.sleep(8000);
		clickOnElement(lp.studentcorner());
		test.log(LogStatus.PASS, "clicked on student corner");
		
		Thread.sleep(5000);
		clickOnElement(lp.allquestion());
		test.log(LogStatus.PASS, "clicked on all question");
		
		Thread.sleep(5000);
        JavascriptExecutor  jse = (JavascriptExecutor) webDriver;
		
		
		jse.executeScript("window.scrollBy(0,180)");
		
		
		Thread.sleep(5000);
		clickOnElement(lp.clickarrow());
		test.log(LogStatus.PASS, "clickarrow  button");
		
		Thread.sleep(5000);
		clickOnElement(lp.writeanswer());
		test.log(LogStatus.PASS, " click on write answer  button");
		
		Thread.sleep(5000);
        JavascriptExecutor  jse1 = (JavascriptExecutor) webDriver;
		
		
		jse1.executeScript("window.scrollBy(0,100)");
		

		Thread.sleep(5000);
		clickOnElement(lp.writeanswerbox());
		Thread.sleep(5000);
		sendValuesToElement(lp.writeanswerbox(), text);
		test.log(LogStatus.PASS, " click on write answer box");
		
		
		Thread.sleep(5000);
        JavascriptExecutor  jse2 = (JavascriptExecutor) webDriver;
		
		
		jse1.executeScript("window.scrollBy(0,280)");
		
		
		Thread.sleep(5000);
		b.sendValuesToElement(lp.file(),"C:\\Users\\RISHIKANDHAN\\Pictures\\sample.jpg");
		test.log(LogStatus.PASS, " file selected  ");
		
		Thread.sleep(5000);
        JavascriptExecutor  jse3 = (JavascriptExecutor) webDriver;
		
		
		jse.executeScript("window.scrollBy(0,80)");
		
		
		Thread.sleep(10000);
		clickOnElement(lp.discardbtn());
		test.log(LogStatus.PASS, "clicked on discard  ");
		
		
		
		
		//clickOnElement(lp.saveBtn());
		//test.log(LogStatus.PASS, "clicked on save  ");
		
		Thread.sleep(8000);
	}
		
		
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"\\data\\EduDataSheet (88).xlsx", "Sheet1", "myanswer");
	}
}


	
	

