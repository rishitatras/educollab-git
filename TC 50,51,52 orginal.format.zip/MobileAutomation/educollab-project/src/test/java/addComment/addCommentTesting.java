package addComment;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import commentListing.commentListing;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class addCommentTesting extends BaseTest { // sprint 54 test case AIO test no 294

	addComment   addobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String text) throws InterruptedException {
		test = extent.startTest("To verify Add Comment under the Session ").assignCategory("Regression Test");
		addobject = new addComment(driver);
		
		Thread.sleep(10000);
		clickOnElement(addobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(addobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(addobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(addobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(addobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(addobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(addobject.getoPassWord());
		sendValuesToElement(addobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(20000);
		clickOnElement(addobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(12000);
		clickOnElement(addobject.getocoursetab());
		test.log(LogStatus.PASS, "Clicked on coursetab");
		
		Thread.sleep(8000);
		(new TouchAction(driver)).press(PointOption.point(982, 1823))
		  .moveTo(PointOption.point(975, 250))
		  .release()
		  .perform();
		
		
		Thread.sleep(15000);
		clickOnElement(addobject.getolanguage());
		test.log(LogStatus.PASS, "Clicked on languages");
		
		Thread.sleep(10000);
		clickOnElement(addobject.getotopic());
		test.log(LogStatus.PASS, "Clicked on topic");
		
		Thread.sleep(15000);
		clickOnElement(addobject.getothridtopic());
		test.log(LogStatus.PASS, "Clicked on thirdtopic");
		
		Thread.sleep(5000);
		clickOnElement(addobject.getocomment());
		test.log(LogStatus.PASS, "Clicked on comment tab");
		
		Thread.sleep(3000);
		clickOnElement(addobject.getoaddcomment());
		Thread.sleep(3000);
		sendValuesToElement(addobject.getoaddcomment(),text);
		test.log(LogStatus.PASS, "Clicked on add text");
		
		Thread.sleep(5000);
		
		//(new TouchAction(driver)).tap(PointOption.point(992, 2164)).perform();
        Thread.sleep(3000);
		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (61).xlsx", "Sheet1", "addCommentTesting");
	}		
		
		
		
}


