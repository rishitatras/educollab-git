package allQuestion;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class allQuestionTest extends BaseTest { // sprint 52 test case AIO test no 272 

	allQuestion   allobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify All Question screen and functionality").assignCategory("Regression Test");
		allobject = new allQuestion(driver);
		
		Thread.sleep(15000);
		clickOnElement(allobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		VerifyelementIsDisplayed(allobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(allobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(allobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(4000);
		clickOnElement(allobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(allobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(4000);
		clickOnElement(allobject.getoPassWord());
		sendValuesToElement(allobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(10000);
		clickOnElement(allobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(10000);
		clickOnElement(allobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
	
		Thread.sleep(10000);
		clickOnElement(allobject.getomeenubutton());
		test.log(LogStatus.PASS,"clicked on meenu button");
		
		Thread.sleep(10000);
		(new TouchAction(driver)).tap(PointOption.point(964, 382)).perform();
Thread.sleep(10000);
	}
//	
//	private String getoUserName() {
//		return null;
//		// TODO Auto-generated method stub
//		//	return null;
//	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (28).xlsx", "Sheet1", "allQuestionTest");
	}
		
}

	
	

