package logout;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import logOutt.logOutt;
import login.login;

public class logouttTest extends BaseTest {

	

	logOutt Outobject;            // sprint 51 Aio Test case no :253
		
		
		@Test(dataProvider="loginData")
		public void ValidCredentials(String email,String password) throws InterruptedException {
			test = extent.startTest("To verify logout functionality on mobile application").assignCategory("Regression Test");
			Outobject = new logOutt (driver);
			Thread.sleep(10000);
			
			clickOnElement(Outobject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Default Login");
			
			Thread.sleep(5000);
			
			VerifyelementIsDisplayed(Outobject.getoDefaultLoginHeader());
			test.log(LogStatus.PASS, "Login Header Is Displayed");
			
			VerifyelementIsDisplayed(Outobject.getoDefaultPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
			
			VerifyelementIsDisplayed(Outobject.getoPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
			
			Thread.sleep(8000);
			clickOnElement(Outobject.getoUserName());
			Thread.sleep(1000);
			sendValuesToElement(Outobject.getoUserName(), email);
			test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
			
			Thread.sleep(8000);
			clickOnElement(Outobject.getoPassWord());
			Thread.sleep(1000);
			sendValuesToElement(Outobject.getoPassWord(),password);
			test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
			
	        Thread.sleep(8000);
			clickOnElement(Outobject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Login");
			
			Thread.sleep(8000);
			clickOnElement(Outobject.getOMeenubar());
			test.log(LogStatus.PASS,"clicked on meenubar");
			
			Thread.sleep(8000);
			clickOnElement(Outobject.getoLogout() );
			test.log(LogStatus.PASS,"clicked on the logout");
			
			Thread.sleep(2000);
		}
			

		private String getoUserName() {
			return null;
			// TODO Auto-generated method stub
			//	return null;
		}

		@DataProvider(name="loginData")
		public Object[][] getLoginData() throws IOException{
			return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (18).xlsx", "Sheet1", "logouttTest");
		}
	}

