package MeenuBar;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import CoursesDetails.CourseDetails;
import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;



	public class MeenuBarTest extends BaseTest{


		
		MeenuBar  BarObject;  // sprint 50 Aio test case 230 
		
		
		@Test(dataProvider="loginData")
		public void ValidCredentials(String email,String password) throws InterruptedException {
			test = extent.startTest("To verify Re-design of menu bar on home screen ").assignCategory("Regression Test");
			BarObject = new MeenuBar(driver);
			Thread.sleep(10000);
			clickOnElement(BarObject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Default Login");
			
			Thread.sleep(5000);
			VerifyelementIsDisplayed(BarObject.getoDefaultLoginHeader());
			test.log(LogStatus.PASS, "Login Header Is Displayed");
			
			VerifyelementIsDisplayed(BarObject.getoDefaultPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
			
			VerifyelementIsDisplayed(BarObject.getoPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
			
			Thread.sleep(8000);
			clickOnElement(BarObject.getoUserName());
			Thread.sleep(1000);
			sendValuesToElement(BarObject.getoUserName(), email);
			test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
			
			clickOnElement(BarObject.getoPassWord());
			Thread.sleep(1000);
			sendValuesToElement(BarObject.getoPassWord(),password);
			test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
			
			Thread.sleep(8000);
			clickOnElement(BarObject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Login");
			
			Thread.sleep(5000);
			buttonClick(BarObject.getOMeenubar());
			test.log(LogStatus.PASS,"clicked on the meenu bar");
			Thread.sleep(1000);
		
		}
		private String getoUserName() {
			return null;
			// TODO Auto-generated method stub
			//	return null;
		}

		@DataProvider(name="loginData")
		public Object[][] getLoginData() throws IOException{
			return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (24).xlsx", "Sheet1", "MeenuBarTest");
		}
}
