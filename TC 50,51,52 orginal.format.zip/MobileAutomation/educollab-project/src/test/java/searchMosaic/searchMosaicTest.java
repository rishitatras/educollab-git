package searchMosaic;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;


public class searchMosaicTest extends BaseTest{


	
	searchMosaic searchObject;       // sprint 50 Aio test case 176
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String search) throws InterruptedException {
		test = extent.startTest("To verify search mosaic home page").assignCategory("Regression Test");
		searchObject = new searchMosaic(driver);
		Thread.sleep(10000);
		clickOnElement(searchObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		Thread.sleep(1000);
		VerifyelementIsDisplayed(searchObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(searchObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(searchObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(8000);
		//sendValuesToElement(CoursesObject.getoUserName(), email);
		clickOnElement(searchObject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(searchObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		clickOnElement(searchObject.getoPassWord());
		Thread.sleep(8000);
		sendValuesToElement(searchObject.getoPassWord(),password);
		Thread.sleep(1000);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		//(CoursesObject.getoDefaultLogin());
		Thread.sleep(10000);
		buttonClick(searchObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(10000);
		buttonClick(searchObject.getOmeenubar());
		test.log(LogStatus.PASS, "Clicked on meenu bar");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(123, 806)).perform();
		
		Thread.sleep(8000);
		buttonClick(searchObject.getOsearchbar());
		Thread.sleep(5000);
		sendValuesToElement(searchObject.getOsearchbar(),search);
		test.log(LogStatus.PASS, "Clicked on search bar");
		
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(999, 2171)).perform();
		test.log(LogStatus.PASS, "Clicked on select");
		Thread.sleep(5000);
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (72).xlsx", "Sheet1", "searchMosaicTest");
	}

	
}

