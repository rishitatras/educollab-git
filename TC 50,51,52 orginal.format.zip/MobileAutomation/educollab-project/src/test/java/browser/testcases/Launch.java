package browser.testcases;

import org.testng.annotations.Test;

import EduCollab.Web.utilities.BaseTest;

public class Launch extends BaseTest{

	@Test
	public void test() {

	}
	
	}
