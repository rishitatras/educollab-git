package detailAnswerscreen;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import tagsAnswer.tagsAnswer;

public class detailAnswerscreenTest  extends BaseTest { // sprint 53 test case AIO test no 287

	detailAnswerscreen   screenobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify detail page of answer in my Answer").assignCategory("Regression Test");
		screenobject = new detailAnswerscreen(driver);
		
		Thread.sleep(10000);
		clickOnElement(screenobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(screenobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(screenobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(screenobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(screenobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(screenobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(screenobject.getoPassWord());
		sendValuesToElement(screenobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(8000);
		clickOnElement(screenobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(screenobject.getoquestiontab());
		test.log(LogStatus.PASS,"clicked on question tab");
	
		
		Thread.sleep(5000);
		clickOnElement(screenobject.getomeenubar());
		test.log(LogStatus.PASS,"clicked on meenu bar");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(964, 873)).perform();
		Thread.sleep(5000);
		
		Thread.sleep(5000);
		clickOnElement(screenobject.getofirstquestion());
		test.log(LogStatus.PASS,"clicked on question");
		
		Thread.sleep(3000);
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (53).xlsx", "Sheet1", "detailAnswerscreenTest");
	}		
		
		
}

	
	

