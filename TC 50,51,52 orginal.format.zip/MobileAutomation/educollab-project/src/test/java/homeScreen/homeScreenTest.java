package homeScreen;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;

public class homeScreenTest extends BaseTest {

	
	homeScreen ScreenObject;  // sprint 55 
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify see more Re-design & functionality on Home Screen  ").assignCategory("Regression Test");
		ScreenObject = new homeScreen(driver);
		
		Thread.sleep(12000);
		clickOnElement(ScreenObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(ScreenObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(ScreenObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(ScreenObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(8000);
		//sendValuesToElement(CoursesObject.getoUserName(), email);
		clickOnElement(ScreenObject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(ScreenObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(5000);
		clickOnElement(ScreenObject.getoPassWord());
		Thread.sleep(1000);
		sendValuesToElement(ScreenObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		Thread.sleep(8000);
		buttonClick(ScreenObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(5000);
		clickOnElement(ScreenObject.getOHomeTab());
		test.log(LogStatus.PASS,"clicked on the Home tab");
		
		Thread.sleep(5000);
	
	
		}
		private String getoUserName() {
			return null;
			//TODO Auto-generated method stub
				//return null;
		}

		@DataProvider(name="loginData")
		public Object[][] getLoginData() throws IOException{
			return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet (64).xlsx", "Sheet1", "homeScreenTest");
		

}
}
