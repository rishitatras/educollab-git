package answerButton;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class answerButton {

	public answerButton (WebDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
	private AndroidElement oDefaultLogin;


	@AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
	private AndroidElement oLoginHeader;

	@AndroidFindBy(accessibility = "Enter your email address and")
	private AndroidElement oEnterYourEmailAddressText;

	@AndroidFindBy(accessibility = "password to access your account")
	private AndroidElement oPasswordToAccessYourAcctText;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]")
	private AndroidElement oUserName;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]")
	private AndroidElement oPassWord;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Login\"]")
	private AndroidElement OLogin;


	 @AndroidFindBy(accessibility="Courses\nTab 2 of 5") 
	    private AndroidElement oCoureseButton;
	
	@AndroidFindBy(accessibility="Languages\n￼\n￼\n￼\nA language is a structured system of communication used by humans consisting of speech and gestures. Most languages have a visual or graphical representation encoded into a writing system, composed of glyphs to inscribe the original sound or gesture and their meaning.\n4.15 (5.0)")
    private AndroidElement olanguage;
    
	
	 
	    @AndroidFindBy(accessibility="Course For Assessment\n￼\n￼\n￼\nCourse For Assessment desc\n0.0 (5.0)")
	    private AndroidElement ocourseforassessement;
	    
	    @AndroidFindBy(accessibility="Course Resources\nTab 3 of 7")
	    private AndroidElement ocourseresources;
	    
	    @AndroidFindBy(accessibility="Instructor(s)/Teaching Assistant\nTab 4 of 7")
	    private AndroidElement oinstructor;
	    
	    @AndroidFindBy(accessibility="Live Sessions\nTab 5 of 7")
	    private AndroidElement olivesession;
	    
	    @AndroidFindBy(accessibility="Assessments\nTab 6 of 7")
	    private AndroidElement oassessmenttab;
	    
	    
		
	    public AndroidElement getoDefaultLogin() {
	    	return oDefaultLogin;
	    }
	    public AndroidElement getoDefaultLoginHeader() {
	    	return oLoginHeader;
	    }
	    public AndroidElement getoDefaultPasswordToAccessYourAcctText() {
	    	return oEnterYourEmailAddressText;
	    }
	    public AndroidElement getoPasswordToAccessYourAcctText() {
	    	return oPasswordToAccessYourAcctText;
	    }
	    
	    public AndroidElement getoUserName() {
	    	return oUserName;
	    	
	    }
	    public AndroidElement getoPassWord() {
	    	return oPassWord;
	    }
	    public AndroidElement getoLogin() {
	    	return OLogin;
	    }
	    public AndroidElement getoCoureseButton() {
	    	return oCoureseButton ;
	    }

	    public AndroidElement getocourseforassessement() {
			return ocourseforassessement;
		
	    }
	    public AndroidElement getocourseresources() {
			return ocourseresources;
	    	
	    }
	    public AndroidElement getoinstructor() {
			return oinstructor;
	    	
	    }
	    public AndroidElement getolivesession() {
			return olivesession;
			
	    	
	    }
	    public AndroidElement getoassessmenttab() {
			return oassessmenttab;
	    	
	    }
	    public AndroidElement getolanguage() {
			return olanguage;
	    }	
	
}
