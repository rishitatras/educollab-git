package filterButton;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class filterButton {

	
	// sprint 53   mobile built number 1038  
		public filterButton (WebDriver driver) {
			PageFactory.initElements(new AppiumFieldDecorator(driver), this);
			
		}

		@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
		//@AndroidFindBy(accessibility ="Login")
		private AndroidElement oDefaultLogin;


		//@AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
		@AndroidFindBy(xpath ="//android.view.View[@content-desc=\"Login\"]")
		
		private AndroidElement oLoginHeader;

		@AndroidFindBy(accessibility = "Enter your email address and")
		private AndroidElement oEnterYourEmailAddressText;

		@AndroidFindBy(accessibility = "password to access your account")
		private AndroidElement oPasswordToAccessYourAcctText;

		@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]")
		private AndroidElement oUserName;

		@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]")
		private AndroidElement oPassWord;

	    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Login\"]")
		private AndroidElement OLogin;

		@AndroidFindBy(accessibility ="Questions\nTab 3 of 5")
		private AndroidElement oquestiontab;
		
		@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View[2]")
		private AndroidElement ofiltericon;
		
		@AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Recent Questions\nMost Visited\"]/android.widget.CheckBox[1]")
		private AndroidElement orecentquestion;
		
		@AndroidFindBy(accessibility =" Machine Learning")
		private AndroidElement oApply1;
		
		@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View[2]")	
		private AndroidElement ofilteriocon1;
		
		@AndroidFindBy(xpath ="//android.view.View[@content-desc=\"Recent Questions\nMost Visited\"]/android.widget.CheckBox[2]")
		private AndroidElement omostvisted;
		
		@AndroidFindBy(accessibility =" Machine Learning")
		private AndroidElement oApply2;
		
		
		public AndroidElement getoDefaultLogin() {
	    	return oDefaultLogin;
	    }
	    public AndroidElement getoDefaultLoginHeader() {
	    	return oLoginHeader;
	    }
	    public AndroidElement getoDefaultPasswordToAccessYourAcctText() {
	    	return oEnterYourEmailAddressText;
	    }
	    public AndroidElement getoPasswordToAccessYourAcctText() {
	    	return oPasswordToAccessYourAcctText;
	    }
	    
	    public AndroidElement getoUserName() {
	    	return oUserName;
	    	
	    }
	    public AndroidElement getoPassWord() {
	    	return oPassWord;
	    }
	    public AndroidElement getoLogin() {
	    	return OLogin;
	    }
	    public AndroidElement getoquestiontab() {
			return oquestiontab;
	    }
	    public AndroidElement getofiltericon() {
			return ofiltericon;
	    	
	    }
		
	    public AndroidElement getorecentquestion(){
			return orecentquestion;
			
	    }
	    public AndroidElement getoApply1() {
			return oApply1;
	    	
	    }
	    public AndroidElement getofilteriocon1() {
			return ofilteriocon1;
	    	
	    }
	    public AndroidElement getomostvisted() {
			return omostvisted;
	    	
	    }
	    public AndroidElement getoApply2() {
			return oApply2;
	    	
	    }
	    
	    
	    
		
}
