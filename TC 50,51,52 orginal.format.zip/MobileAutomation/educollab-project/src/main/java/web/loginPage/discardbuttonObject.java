package web.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class discardbuttonObject  extends BaseTest {

	public discardbuttonObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
	}
	@FindBy(xpath="//li[contains(@class,'nav-item student-dropdown ng-star-inserted dropdown')]//a[@id='navbarDropdown']")
	private WebElement studentcorner;
	
	public WebElement studentcorner() {
		return studentcorner;
		
	}

	@FindBy(xpath ="//a[normalize-space()='My Questions']")
	private WebElement myquestion;
	
	public WebElement myquestion() {
		return myquestion;
		
	}
	
	@FindBy(xpath ="//button[normalize-space()='Ask a Question ?']")
	private WebElement askquestion;
	
	public WebElement askquestion() {
		return askquestion;
		
	}
    @FindBy(xpath="//select[@class='form-control form-control-style-2 form-control-lg form-control-caret ng-untouched ng-pristine ng-invalid']")
    private WebElement category;
		
    public WebElement category() {
		return category;
		
    }
		
    @FindBy(xpath="//input[@placeholder='Coin Amount']")
    private WebElement coins;
	
    public WebElement coins() {
		return coins;
		
    }
    @FindBy(xpath="//input[@placeholder='Enter tags seperated by comma']")
    private WebElement questiontag;
	
    public WebElement questiontag() {
		return questiontag;
		
    }
    @FindBy(xpath= "//textarea[@placeholder='Write your Question here.']")
 private WebElement question;
	
    public WebElement question() {
		return question;
		
    }
    
   
    @FindBy(xpath="//input[@class='file-upload-input ']")
private WebElement file;
	
    public WebElement file() {
		return file;
    }	
  //button[normalize-space()='Discard']
    @FindBy(xpath="//button[normalize-space()='Discard']")
    private WebElement discard;
    	
        public WebElement discard() {
    		return discard;
        }	

    @FindBy(xpath="//button[normalize-space()='Save']")
    private WebElement saveBtn;
    	
        public WebElement saveBtn() {
    		return saveBtn;
        }	
}