package editMyanswer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class editMyanswer {

	
	// sprint 53   mobile built number 1038  
			public editMyanswer (WebDriver driver) {
				PageFactory.initElements(new AppiumFieldDecorator(driver), this);
				
			}

			@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
			private AndroidElement oDefaultLogin;


			@AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
			private AndroidElement oLoginHeader;

			@AndroidFindBy(accessibility = "Enter your email address and")
			private AndroidElement oEnterYourEmailAddressText;

			@AndroidFindBy(accessibility = "password to access your account")
			private AndroidElement oPasswordToAccessYourAcctText;

			@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]")
			private AndroidElement oUserName;

			@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]")
			private AndroidElement oPassWord;

			@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Login\"]")
			private AndroidElement OLogin;

			@AndroidFindBy(accessibility ="Questions\nTab 3 of 5")
			private AndroidElement oquestiontab;
			
			@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View[3]")
			private AndroidElement omeenubar;
			
			@AndroidFindBy(xpath ="(//android.view.View[@content-desc=\"Suppose you have used your favourite binary classification algorithm to learn a hypothesis h1 from some training data. You are interested in knowing the accuracy that the hypothesis can be expected to achieve on the underlying population. To assess this accuracy you apply the hypothesis to a test data set consisting of 45 instances that you had held back from the training data set. The error rate observed on the test data is 6.67%. Calculate the 95% confidence interval for the true error?\nMachine Learning\"])[1]")
			private AndroidElement oquestion;
			
			@AndroidFindBy(accessibility ="Edit answer")
			private AndroidElement oeditoption;
			
			@AndroidFindBy(id ="com.android.permissioncontroller:id/permission_allow_foreground_only_button")
			private AndroidElement opermissionicon;
			
			
			@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[6]/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.widget.EditText")
			private AndroidElement oedittext;
			
			
			
			@AndroidFindBy(accessibility ="Submit")
			private AndroidElement osubmitbutton;
			
			@AndroidFindBy(accessibility ="Yes")
			private AndroidElement oyesbutton;
			
			public AndroidElement getoDefaultLogin() {
		    	return oDefaultLogin;
		    }
		    public AndroidElement getoDefaultLoginHeader() {
		    	return oLoginHeader;
		    }
		    public AndroidElement getoDefaultPasswordToAccessYourAcctText() {
		    	return oEnterYourEmailAddressText;
		    }
		    public AndroidElement getoPasswordToAccessYourAcctText() {
		    	return oPasswordToAccessYourAcctText;
		    }
		    
		    public AndroidElement getoUserName() {
		    	return oUserName;
		    	
		    }
		    public AndroidElement getoPassWord() {
		    	return oPassWord;
		    }
		    public AndroidElement getoLogin() {
		    	return OLogin;
		    }
		    public AndroidElement getoquestiontab() {
				return oquestiontab;
		    }
		    public AndroidElement getomeenubar() {
				return omeenubar;
		    	
		    }
		    public AndroidElement getoquestion() {
				return oquestion;
		    	
		    }
		    public AndroidElement getoeditoption(){
				return oeditoption;
		    	
		    }
		    public AndroidElement getopermissionicon(){
				return opermissionicon;
		    	
		    }
		    
		    public AndroidElement getoedittext() {
				return oedittext;
		    	
		    }
		    public AndroidElement getosubmitbutton() {
				return osubmitbutton;
		    	
		    }
		    public AndroidElement getoyesbutton() {
				return oyesbutton;
				
		    	
		    }
		    
		    
		    
}
