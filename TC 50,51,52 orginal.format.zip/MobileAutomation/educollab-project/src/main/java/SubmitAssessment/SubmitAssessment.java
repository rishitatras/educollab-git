package SubmitAssessment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class SubmitAssessment {

	public SubmitAssessment(WebDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
	private AndroidElement oDefaultLogin;
	
 
    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
    private AndroidElement oLoginHeader;
    
    @AndroidFindBy(accessibility = "Enter your email address and")
    private AndroidElement oEnterYourEmailAddressText;
    
    @AndroidFindBy(accessibility = "password to access your account")
    private AndroidElement oPasswordToAccessYourAcctText;
    
    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]")
    private AndroidElement oUserName;
    
    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]")
    private AndroidElement oPassWord;
    
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Login\"]")
    private AndroidElement OLogin;
    
    @AndroidFindBy(accessibility="Courses\nTab 2 of 5")
    private AndroidElement oCoureseButton;
    
    @AndroidFindBy(accessibility="Languages\n￼\n￼\n￼\nA language is a structured system of communication used by humans consisting of speech and gestures. Most languages have a visual or graphical representation encoded into a writing system, composed of glyphs to inscribe the original sound or gesture and their meaning.\n4.0 (5.0)")
    private AndroidElement oLanguages;
    
    @AndroidFindBy(accessibility="Topics/Curriculum\nTab 1 of 7")
    private AndroidElement oTopicsAndCurriculum;
    
    
    @AndroidFindBy(accessibility="1. Old Topic\n10 Videos - \n01:37:10 hours\n4 Assessment, 4 Coursework & 2 Resource")
    private AndroidElement ooldTopic;
    
    @AndroidFindBy(xpath="//android.view.View[@content-desc=\\\"Answer\\\"])[1]")
    private AndroidElement oAnswer;
    
    
    @AndroidFindBy(accessibility ="com.android.permissioncontroller:id/permission_allow_foreground_only_button")
    private AndroidElement oPermissionApp;
    
    @AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[5]")
    private AndroidElement oNextArrow;
    
    @AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[3]")
    private AndroidElement oPreviousArrow;
    
    public AndroidElement getoDefaultLogin() {
    	return oDefaultLogin;
    }
    public AndroidElement getoDefaultLoginHeader() {
    	return oLoginHeader;
    }
    public AndroidElement getoDefaultPasswordToAccessYourAcctText() {
    	return oEnterYourEmailAddressText;
    }
    public AndroidElement getoPasswordToAccessYourAcctText() {
    	return oPasswordToAccessYourAcctText;
    }
    
    public AndroidElement getoUserName() {
    	return oUserName;
    	
    }
    public AndroidElement getoPassWord() {
    	return oPassWord;
    }
    public AndroidElement getoLogin() {
    	return OLogin;
    }
    public AndroidElement getoCoureseButton() {
    	return oCoureseButton ;
    }
    
    public AndroidElement getoLanguages() {
		return oLanguages;
    	
    }
    
    public AndroidElement getoTopicsAndCurriculum() {
		return oTopicsAndCurriculum;
    	
    }
    
    public AndroidElement getooldTopic() {
		return ooldTopic  ;
    }
		public AndroidElement getoAnswer() {
			return oAnswer;
			
			
		}
		public AndroidElement getoPermissionApp() {
			return oPermissionApp;
			
		}
		public AndroidElement getoNextArrow() {
			return oNextArrow;
			
		}
		public AndroidElement getoPreviousArrow() {
			return OLogin;
			
		}
	
	}
    

