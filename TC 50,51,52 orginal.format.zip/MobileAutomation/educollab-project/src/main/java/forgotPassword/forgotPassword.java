package forgotPassword;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class forgotPassword {

	public forgotPassword(WebDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
	private AndroidElement oDefaultLogin;
	
 
    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
    private AndroidElement oLoginHeader;
    
    @AndroidFindBy(accessibility = "Enter your email address and")
    private AndroidElement oEnterYourEmailAddressText;
    
    @AndroidFindBy(accessibility = "password to access your account")
    private AndroidElement oPasswordToAccessYourAcctText;
    
    @AndroidFindBy(accessibility ="Forgot Password?")
    private AndroidElement oForgotPassword;
    
    @AndroidFindBy(accessibility ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText")
    private AndroidElement oEmail;
    
    @AndroidFindBy(accessibility ="Send OTP")
    private AndroidElement oSendotp;
    
    
    public AndroidElement getoDefaultLogin() {
    	return oDefaultLogin;
    }
    public AndroidElement getoDefaultLoginHeader() {
    	return oLoginHeader;
    }
    public AndroidElement getoDefaultPasswordToAccessYourAcctText() {
    	return oEnterYourEmailAddressText;
    }
    public AndroidElement getoPasswordToAccessYourAcctText() {
    	return oPasswordToAccessYourAcctText;
    }
     public AndroidElement  getoForgotPassword() {
		return oForgotPassword;
    	
    }
    
    public AndroidElement getoEmail() {
		return oEmail;
    	
    }
    public AndroidElement getoSendotp() {
		return oSendotp;
		
    	
    }
	
}
