package editNote;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class editNote {

	public editNote (WebDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
	private AndroidElement oDefaultLogin;


	@AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
	private AndroidElement oLoginHeader;

	@AndroidFindBy(accessibility = "Enter your email address and")
	private AndroidElement oEnterYourEmailAddressText;

	@AndroidFindBy(accessibility = "password to access your account")
	private AndroidElement oPasswordToAccessYourAcctText;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]")
	private AndroidElement oUserName;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]")
	private AndroidElement oPassWord;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Login\"]")
	private AndroidElement OLogin;

	@AndroidFindBy(accessibility ="Courses\nTab 2 of 5")
	private AndroidElement ocoursetab;
	
	@AndroidFindBy(accessibility ="Languages\n￼\n￼\n￼\nA language is a structured system of communication used by humans consisting of speech and gestures. Most languages have a visual or graphical representation encoded into a writing system, composed of glyphs to inscribe the original sound or gesture and their meaning.\n4.15 (5.0)")
	private AndroidElement olanguage;
	
	@AndroidFindBy(accessibility ="1. Old Topic\n10 Videos - \n01:37:10 hours\n5 Assessment, 4 Coursework & 3 Resource")
	private AndroidElement otopic;
	
	@AndroidFindBy(accessibility ="3 Test 4 \n00:02:18")
	private AndroidElement othridtopic;
	
	@AndroidFindBy(accessibility ="Notes\nTab 2 of 7")
	private AndroidElement onote;
	
	@AndroidFindBy(xpath ="//android.view.View[@content-desc=\"00:00:47\ntesting\n￼\n￼\nKakhah\"]/android.view.View")
	private AndroidElement othreeidot;
	
	@AndroidFindBy(accessibility ="Edit\nEdit this note")
	private AndroidElement oedit;
	
	@AndroidFindBy(id ="com.android.permissioncontroller:id/permission_allow_foreground_only_button")
	private AndroidElement opermission;
	
	@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[5]/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.widget.EditText")
	private AndroidElement otext;
	
	@AndroidFindBy(accessibility ="Upload your resources here\nSupports image, pdf & text files")
	private AndroidElement ouploadfile;
	
	@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View[1]")
	private AndroidElement ogallery;
	
	@AndroidFindBy(id ="com.android.permissioncontroller:id/permission_allow_button")
	private AndroidElement oallowbutton;
	
	@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.GridView/android.widget.LinearLayout[1]/android.widget.TextView")
	private AndroidElement oselectgallery;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, January 28, 2023 20:24:43\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement oselectphoto;
	
	@AndroidFindBy(accessibility ="OK")
	private AndroidElement ookbutton;
	
	@AndroidFindBy(accessibility ="Update")
	private AndroidElement oupdate;
	
	
	public AndroidElement getoDefaultLogin() {
    	return oDefaultLogin;
    }
    public AndroidElement getoDefaultLoginHeader() {
    	return oLoginHeader;
    }
    public AndroidElement getoDefaultPasswordToAccessYourAcctText() {
    	return oEnterYourEmailAddressText;
    }
    public AndroidElement getoPasswordToAccessYourAcctText() {
    	return oPasswordToAccessYourAcctText;
    }
    
    public AndroidElement getoUserName() {
    	return oUserName;
    	
    }
    public AndroidElement getoPassWord() {
    	return oPassWord;
    }
    public AndroidElement getoLogin() {
    	return OLogin;
    }
	
    public AndroidElement getocoursetab() {
		return ocoursetab;
    	
    }
    public AndroidElement getolanguage() {
		return olanguage;
    	
    }
    public AndroidElement getotopic() {
		return otopic;
    	
    }
    public AndroidElement getothridtopic() {
		return othridtopic;
    	
    }
    public AndroidElement getonote() {
		return onote;
    	
    }
    public AndroidElement getothreeidot() {
		return othreeidot;
    	
    }
    public AndroidElement getoedit() {
		return oedit;
    	
    }
    public AndroidElement getopermission(){
		return opermission;
    	
    }
    public AndroidElement getotext() {
		return otext;
    	
    }
    public AndroidElement getouploadfile() {
		return ouploadfile;
    	
    }
    public AndroidElement getogallery() {
		return ogallery;
    	
    }
    public AndroidElement getoallowbutton() {
		return oallowbutton;
    	
    }
    public AndroidElement getoselectgallery() {
		return oselectgallery;
    	
    }
    public AndroidElement getoselectphoto() {
		return oselectphoto;
    	
    }
    public AndroidElement getookbutton() {
		return ookbutton;
    	
    }
    public AndroidElement getoupdate() {
		return oupdate;
    	
    }
    
    
    
}
