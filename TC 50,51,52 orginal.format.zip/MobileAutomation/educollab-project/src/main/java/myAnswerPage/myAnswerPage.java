package myAnswerPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class myAnswerPage {

	// sprint 53   mobile built number 1038  
	public myAnswerPage (WebDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
	private AndroidElement oDefaultLogin;


	@AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
	private AndroidElement oLoginHeader;

	@AndroidFindBy(accessibility = "Enter your email address and")
	private AndroidElement oEnterYourEmailAddressText;

	@AndroidFindBy(accessibility = "password to access your account")
	private AndroidElement oPasswordToAccessYourAcctText;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]")
	private AndroidElement oUserName;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]")
	private AndroidElement oPassWord;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Login\"]")
	private AndroidElement OLogin;

	@AndroidFindBy(accessibility ="Questions\nTab 3 of 5")
	private AndroidElement oquestiontab;
	
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View[3]")
	private AndroidElement omeenubar;
	
	
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View[2]")
	private AndroidElement oFiltericon1;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Text Answer\nVideo Answer\"]/android.widget.CheckBox[1]")
	private AndroidElement otextanswer;
	
	@AndroidFindBy(accessibility ="Accountancy")
	private AndroidElement oapplybutton1;
	
	@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View[2]")
	private AndroidElement oFiltericon2;
	
	@AndroidFindBy(xpath ="//android.view.View[@content-desc=\"Text Answer\nVideo Answer\"]/android.widget.CheckBox[2]")
	private AndroidElement ovideoanswer;

	
	@AndroidFindBy(accessibility ="Accountancy")
	private AndroidElement oapplybutton2;



	public AndroidElement getoDefaultLogin() {
    	return oDefaultLogin;
    }
    public AndroidElement getoDefaultLoginHeader() {
    	return oLoginHeader;
    }
    public AndroidElement getoDefaultPasswordToAccessYourAcctText() {
    	return oEnterYourEmailAddressText;
    }
    public AndroidElement getoPasswordToAccessYourAcctText() {
    	return oPasswordToAccessYourAcctText;
    }
    
    public AndroidElement getoUserName() {
    	return oUserName;
    	
    }
    public AndroidElement getoPassWord() {
    	return oPassWord;
    }
    public AndroidElement getoLogin() {
    	return OLogin;
    }
    public AndroidElement getoquestiontab() {
		return oquestiontab;
    }
    public AndroidElement getomeenubar() {
		return omeenubar;
    	
    }
    public AndroidElement getoFiltericon1() {
		return oFiltericon1;
    	
    }
    public AndroidElement getotextanswer() {
		return otextanswer;
    	
    }
    public AndroidElement getoapplybutton1() {
		return oapplybutton1;
    	
    }
    public AndroidElement getoFiltericon2() {
		return oFiltericon2;
    	
    }
    public AndroidElement getovideoanswer() {
		return ovideoanswer;
    	
    }
    public AndroidElement getoapplybutton2() {
		return oapplybutton2;
    	
    }
    
    
    
    
}
