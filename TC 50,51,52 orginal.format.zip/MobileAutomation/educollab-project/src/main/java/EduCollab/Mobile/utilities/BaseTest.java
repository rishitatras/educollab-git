 package EduCollab.Mobile.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BaseTest extends BaseClass {
	public static ExtentReports extent;
	public ExtentTest test;
	Properties prop = new Properties();

	@AfterMethod
	public void tearDown(ITestResult result) {
		if (test != null) {
			if (result.getStatus() == ITestResult.FAILURE) {
				Calendar oCalendar = Calendar.getInstance();
				SimpleDateFormat dtFormater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
				String sMethodName = result.getName() + "_" + dtFormater.format(oCalendar.getTime()) + ".png";
				String screenshot_path = ExtentReport.CaptureScreen(System.getProperty("user.dir")+ "\\target\\surefire-reports\\extent-report\\screenshots\\" + sMethodName);
				test.log(LogStatus.FAIL, result.getName() + " Screenshot :", test
						.addScreenCapture("." + screenshot_path.substring(screenshot_path.indexOf("\\screenshots"))));
			} else if (result.getStatus() == ITestResult.SKIP) {
				test.log(LogStatus.SKIP, "Test skipped " + result.getThrowable(), "");
			}
		}
		extent.flush();
		driver.quit();
	}

	@BeforeSuite
	public static void beforeSuite() throws IOException {
		FileUtils.deleteDirectory(
				new File(System.getProperty("user.dir") + "\\target\\surefire-reports\\extent-report\\screenshots"));
		System.out.println(System.getProperty("user.dir"));
		extent = ExtentReport.Instance();
	}

	@BeforeMethod
	public void ApplicationSetUp() throws IOException, InterruptedException {
		prop.load(new FileInputStream(new File(System.getProperty("user.dir") + "/data/Environment.properties")));
		System.out.println(prop.getProperty("platform"));
		System.out.println(prop.getProperty("device"));
		new BaseClass().ApplicationLaunch(prop.getProperty("platform"), prop.getProperty("device"));
	}

	@AfterTest
	public void afterTest() {
		extent.endTest(test);
	}

}
