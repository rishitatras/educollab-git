package EduCollab.Mobile.LoginPage.libraries;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoginPageObjects {

	public LoginPageObjects(WebDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
    private AndroidElement oDefaultLogin;
    
    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
    private AndroidElement oLoginHeader;
    
    @AndroidFindBy(accessibility = "Enter your email address and")
    private AndroidElement oEnterYourEmailAddressText;
    
    @AndroidFindBy(accessibility = "password to access your account")
    private AndroidElement oPasswordToAccessYourAcctText;
    
    @AndroidFindBy(className = "android.widget.EditText")
    private AndroidElement oUserName;
    
    @AndroidFindBy(className = "android.widget.EditText")
    private AndroidElement oPassWord;
    
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
    private AndroidElement OLogin;
    
    @AndroidFindBy(xpath = "/hierarchy/android.widget.Toast")
    private AndroidElement OInvalidUserNameAndPasswordPrompt;
    
    @AndroidFindBy(accessibility = "Password is not valid")
    private AndroidElement oErrorPasswordNotValid;
    
    @AndroidFindBy(xpath = "(//android.view.View[@content-desc='*Mandatory Field'])[1]")
    private AndroidElement oMandatoryFieldMissing;
    
    @AndroidFindBy(xpath = "(//android.view.View[@content-desc='*Mandatory Field'])[1]")
    private AndroidElement oMandatoryFieldMissingUserName;
    
    @AndroidFindBy(xpath = "(//android.view.View[@content-desc='*Mandatory Field'])[1]")
    private AndroidElement oMandatoryFieldMissingPassword;
    
    @AndroidFindBy(xpath = "(//android.view.View[@content-desc='Forgot Password?'])[1]")
    private AndroidElement oforgotPasswordLink;
    

    public AndroidElement getOforgotPasswordLink() {
		return oforgotPasswordLink;
	}

	public AndroidElement getoDefaultLogin() {
		return oDefaultLogin;
	}

	public AndroidElement getoLoginHeader() {
		return oLoginHeader;
	}

	public AndroidElement getoEnterYourEmailAddressText() {
		return oEnterYourEmailAddressText;
	}

	public AndroidElement getoPasswordToAccessYourAcctText() {
		return oPasswordToAccessYourAcctText;
	}

	public AndroidElement getoUserName() {
		return oUserName;
	}

	public AndroidElement getoPassWord() {
		return oPassWord;
	}

	public AndroidElement getOLogin() {
		return OLogin;
	}

	public AndroidElement getOInvalidUserNameAndPasswordPrompt() {
		return OInvalidUserNameAndPasswordPrompt;
	}

	public AndroidElement getoErrorPasswordNotValid() {
		return oErrorPasswordNotValid;
	}

	public AndroidElement getoMandatoryFieldMissing() {
		return oMandatoryFieldMissing;
	}

	public AndroidElement getoMandatoryFieldMissingUserName() {
		return oMandatoryFieldMissingUserName;
	}

	public AndroidElement getoMandatoryFieldMissingPassword() {
		return oMandatoryFieldMissingPassword;
	}
    
}
