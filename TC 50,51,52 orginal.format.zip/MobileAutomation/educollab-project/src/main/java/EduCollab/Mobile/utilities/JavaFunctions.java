 package EduCollab.Mobile.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.Reporter;

/**
 *  * Class for java functions  * @author automation  *  
 */
public class JavaFunctions {

	private static final String DATEFORMAT = "MMMM dd, yyyy";

	/**
	 * Returns an array of strings from the beginning of table to the end of the
	 * table
	 * 
	 * @param sDataExcelPath
	 *            absolute path of the workbook
	 * @param sDataSheetName
	 *            name of the worksheet in the workbook
	 * @param sDataTableName
	 *            name of the table present in the sheet
	 * @return An array of contents between starting and ending of table
	 * @throws IOException
	 *             - if an I/O error occurs.
	 */

	public String[][] getTableArray(String sDataExcelPath, String sDataSheetName, String sDataTableName)
			throws IOException {
		String[][] tabArray = null;
		Sheet excelWSheet;
		Workbook excelWBook = null;
		Cell cell = null;
		int iStartRow;
		int iStartCol;
		int iEndRow;
		int iEndCol;
		int ci;
		int cj;
		// Open the Excel file
		FileInputStream excelFile = new FileInputStream(new File(sDataExcelPath));
		try {
			// Access the required test data sheet
			excelWBook = WorkbookFactory.create(excelFile);
			excelWSheet = excelWBook.getSheet(sDataSheetName);
			// To get the start row and starting column of the data table
			iStartRow = findFirstRow(excelWSheet, sDataTableName)[0];
			iStartCol = findFirstRow(excelWSheet, sDataTableName)[1];
			// To get the ending row and ending column of the data table
			iEndRow = findLastRow(excelWSheet, sDataTableName)[0];
			iEndCol = findLastRow(excelWSheet, sDataTableName)[1];
			// Create two dimensional array to store the values
			tabArray = new String[iEndRow - iStartRow - 1][iEndCol - iStartCol - 1];
			
			ci = 0;

			// To read the values from the cell and write it into array
			for (int i = iStartRow + 1; i < iEndRow; i++, ci++) {
				cj = 0;
				for (int j = iStartCol + 1; j < iEndCol; j++, cj++) {
					cell = excelWSheet.getRow(i).getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
					switch (cell.getCellType()) {
					case NUMERIC:
						tabArray[ci][cj] = Double.toString(cell.getNumericCellValue());
						break;
					case STRING:
						if (cell.getStringCellValue() != null)
							tabArray[ci][cj] = cell.getStringCellValue();
						else
							tabArray[ci][cj] = "";
						break;
					default:
						break;
					}

				}
			}
			excelWBook.close();
			excelFile.close();
			return tabArray;
		} catch (Exception e) {
			Reporter.log("Failed" + e);
			excelFile.close();
			return tabArray;
		}

	}

	private static int[] findLastRow(Sheet sheet, String sDataTable) {
		/*
		 *         *  This is the method to find the first instance of row and column
		 * number of the given data table        
		 */
		int[] arrintCellInfo = new int[2];
		int iCount = 0;
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getCellType() == CellType.STRING
						&& cell.getRichStringCellValue().getString().equals(sDataTable)) {
					arrintCellInfo[0] = row.getRowNum();
					arrintCellInfo[1] = cell.getColumnIndex();
					iCount++;
					if (iCount > 1)
						return arrintCellInfo;
				}
			}
		}
		return arrintCellInfo;
	}

	private static int[] findFirstRow(Sheet sheet, String sDataTable) {

		int[] arrintCellInfo = new int[2];
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getCellType() == CellType.STRING
						&& cell.getRichStringCellValue().getString().equals(sDataTable)) {
					arrintCellInfo[0] = row.getRowNum();
					arrintCellInfo[1] = cell.getColumnIndex();
					return arrintCellInfo;
				}
			}
		}
		return arrintCellInfo;
	}

	/**
	 *  * Returns the String which has no special characters  * @param sActualString
	 * string whose special characters need to be removed  * @return the string with
	 * no special characters in it  
	 */

	public String removeSpecialCharacters(String sActualString) {
		StringBuilder sModifiedString = new StringBuilder();
		for (int i = 0; i < sActualString.length(); i++) {
			{
				sModifiedString.append(Character.toString(sActualString.charAt(i)));
			}
		}
		return sModifiedString.toString();
	}

	/**
	 * Returns double value of the given string The value of the string must be
	 * decimal passed as string . eg., "2.35" returns 2.35 or strings and numbers
	 * separated by space eg., "53 ab" returns 53.0 Throws NoSuchElementException if
	 * the string value is other than decimals
	 * 
	 * @param sStringContent
	 *            string value which needs to be converted to double
	 * @return returns the double value from the string content
	 */

	public double getDoubleFromString(String sStringContent) {
		Scanner oScanner = new Scanner(sStringContent);
		while (!oScanner.hasNextDouble()) {
			oScanner.next();
		}
		double dValue = oScanner.nextDouble();
		oScanner.close();
		return dValue;
	}

	/**
	 *  * Specialization of format  * @param dValue number to be formatted
	 *  * @return  returns string in the formatted pattern  
	 */
	public String formatDoubleValue(double dValue) {
		DecimalFormat oFormat = new DecimalFormat("00.##");
		return oFormat.format(dValue);
	}
}