package EduCollab.Mobile.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.MoveMouseAction;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.AbstractOptionCombinedWithPosition;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	
    public static WebDriver webDriver=null;
    
	public static AppiumDriver driver = null;

	DesiredCapabilities capabilities = new DesiredCapabilities();
	Properties prop = new Properties();
	public WebDriver BrowserLaunch(String BrowserName, String environment) {
		if (BrowserName.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			webDriver = new ChromeDriver();
		}else if (BrowserName.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			webDriver = new EdgeDriver();
		}
		webDriver.manage().window().maximize();
		webDriver.manage().deleteAllCookies();
		if (environment.equalsIgnoreCase("qa")) {
			webDriver.get("https://qa.edu-collab.com/");
		}
		return webDriver;
		
	}
	
	public AppiumDriver ApplicationLaunch(String osName, String deviceID) {
		try {
			prop.load(new FileInputStream(new File(System.getProperty("user.dir") + "/data/Environment.properties")));
		} catch (Exception e1) {
			// TODO Auto-generated catch block 
			e1.printStackTrace();
		} 
		if (osName.equalsIgnoreCase("android")) {
			capabilities.setCapability("deviceName", deviceID);
			
			capabilities.setCapability("platformName", "Android");
			System.out.println("Environment: ======= "+prop.getProperty("environment"));
			if (prop.getProperty("environment").equals("qa")) {
				capabilities.setCapability("appPackage", "tatras.educollab.qa");
			}else if (prop.getProperty("environment").equals("stage")) {
				capabilities.setCapability("appPackage", "tatras.educollab.stage");
			}
			
			capabilities.setCapability("appActivity", "tatras.educollab.MainActivity");
			try {
				driver = new AppiumDriver(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		} else if (osName.equalsIgnoreCase("ios")) {
			capabilities = DesiredCapabilities.iphone();
			capabilities.setCapability("deviceName", deviceID);
			capabilities.setCapability("platformName", "iOS");
			// Java package of the Android app you want to run

			if (prop.getProperty("environment").equals("qa")) {
				capabilities.setCapability("appPackage", "tatras.educollab.qa");
			}else if (prop.getProperty("environment").equals("stage")) {
				capabilities.setCapability("appPackage", "tatras.educollab.stage");
			}
			// Activity name for the Android activity want to launch from your Mobile
			capabilities.setCapability("appActivity", "tatras.educollab.MainActivity");
		}
		return driver;
	}

	public void clickOnElement(WebElement oElement) {
		oElement.click();
	}
	public void TapOnElement(WebElement oElement) {
		TouchActions action = new TouchActions(driver);
		action.singleTap(oElement);
		action.perform();
	}
	public void PointOption(WebElement oElement) {
		TouchAction touchAction = new TouchAction(driver);
		//recommeded course
		//touchAction.tap(PointOption.point(943, 1655)).perform();
		//submitt assement 
		//touchAction.tap(PointOption.point(782, 1953)).perform();
		//globalsearch
		//touchAction.tap(PointOption.point(985, 2181)).perform();
		// detailed question 
		//touchAction.tap(PointOption.point(989, 2178)).perform();
		//ask question
		// touchAction.tap(PointOption.point(964, 1950)).perform();
	
	//touchAction.tap(PointOption.point(971, 1339)).perform();	
		// (new TouchAction(driver)).tap(PointOption.point(77, 1112)).perform();
	
}
	public void swipe(WebElement oElement) {
	//(new TouchAction(driver))
//	recommended course
//	  .press(PointOption.point(810, 2086))
//	  .moveTo(PointOption.point(810, 1553))
//	  .release()
//	  .perform();

//	.press(PointOption.point(856, 2086))
//    .moveTo(PointOption.point(880, 140))
//    .release()
//	.perform();
//}
	//featured courses
//	(new TouchAction(driver))
//	  .press(PointOption.point(743, 1508))
//	  .moveTo(PointOption.point(824, 189))
//	  .release()
//	  .perform();
//	}
	}

	public void scrollOnElement(WebElement oElement) {
//		TouchAction action = new TouchAction(driver);
//		action.press(PointOption.point(880, 140)).perform();
//	}
	}
	
	public boolean VerifyelementIsDisplayed(WebElement oElement) {
		return oElement.isDisplayed();
	}

	public void sendValuesToElement(WebElement oElement, String value) {
		oElement.sendKeys(value);
	}

	public boolean courses(WebElement oElement) {
		return oElement.isDisplayed();
	}

	public boolean selectOptions(WebElement oElement) {
		return oElement.isSelected();
	}
	

	public boolean enabled(WebElement oElement) {
		return oElement.isEnabled();
	}

	public void buttonClick(WebElement OElement) {
		OElement.click();
	}

	public void entertext(WebElement oElement, String text) {
		oElement.sendKeys(text);
	}

	public String gettingTitle() {
		String title = driver.getTitle();
		return title;
	}

	public String gettingText(WebElement oElement) {
		String text = oElement.getText();
		return text;
	}

	public String gettingAttribute(WebElement oElement, String attributename) {
		String attribute = oElement.getAttribute(attributename);
		return attribute;
	}

	public static void selectionByIndex(WebElement oElement, int Index) {
		Select s = new Select(oElement);
		s.selectByIndex(Index);
	}
//	//public void scroll() {
//		JavaScriptExecutor jse = (JavaScriptExecutor)driver;
//		jse.executeScript("window.scrollBy(0,1000)");		
//		
	
//}

	public void selectionByValue(WebElement oElement, String value) {
		Select s = new Select(oElement);
		s.selectByValue(value);
		
	
		
	}

	public List<WebElement> getAllSelectedOptions(WebElement oElement) {
		Select s = new Select(oElement);
		return s.getAllSelectedOptions();
	}

	public WebElement getFirstSelectedOptions(WebElement oElement) {
		Select s = new Select(oElement);
		return s.getFirstSelectedOption();
	}

	public List<WebElement> getOPtions(WebElement oElement) {
		Select s = new Select(oElement);
		return s.getOptions();
	}

	public boolean isMultiple(WebElement oElement) {
		Select s = new Select(oElement);
		return s.isMultiple();
	}
	
	public void submit(WebElement oElement) {
		oElement.submit();
	}
	public void setattribute(WebElement oElement,String data) {
		JavascriptExecutor executor = (JavascriptExecutor)webDriver;
		executor.executeScript("arguments[0].setattribute('value'," + data + ")", oElement);
	}
}