package uploadFile;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class uploadFile {

	public uploadFile (WebDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
	private AndroidElement oDefaultLogin;


	@AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
	private AndroidElement oLoginHeader;

	@AndroidFindBy(accessibility = "Enter your email address and")
	private AndroidElement oEnterYourEmailAddressText;

	@AndroidFindBy(accessibility = "password to access your account")
	private AndroidElement oPasswordToAccessYourAcctText;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]")
	private AndroidElement oUserName;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]")
	private AndroidElement oPassWord;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Login\"]")
	private AndroidElement OLogin;

	@AndroidFindBy(accessibility ="Courses\nTab 2 of 5")
	private AndroidElement ocoursetab;
	
	@AndroidFindBy(accessibility ="Languages\n￼\n￼\n￼\nA language is a structured system of communication used by humans consisting of speech and gestures. Most languages have a visual or graphical representation encoded into a writing system, composed of glyphs to inscribe the original sound or gesture and their meaning.\n4.15 (5.0)")
	private AndroidElement olanguage;
	
	@AndroidFindBy(accessibility ="1. Old Topic\n10 Videos - \n01:37:10 hours\n4 Assessment, 4 Coursework & 2 Resource")
	private AndroidElement otopic;
	
	@AndroidFindBy(accessibility ="3 Test 4 \n00:02:18")
	private AndroidElement othridtopic;
	
	@AndroidFindBy(id="com.android.permissioncontroller:id/permission_allow_foreground_only_button")
	private AndroidElement opermission;
	
	@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.widget.EditText")
	private AndroidElement onotetitle;
	
	@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[5]/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.widget.EditText")
	private AndroidElement oenternote;
	
	@AndroidFindBy(accessibility ="Upload your resources here\nSupports image, pdf & text files")
	private AndroidElement ouploadfile;
	
	@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View[1]")
	private AndroidElement ogallery;
	
	@AndroidFindBy(id ="com.android.permissioncontroller:id/permission_allow_button")
	private AndroidElement oallowbutton;
	
	@AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.GridView/android.widget.LinearLayout[1]/android.widget.TextView")
	private AndroidElement oselectgallery;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:50\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto1;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:48\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto2;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:47\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto3;
	
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:45\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto4;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:33\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto5;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:31\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto6;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:28\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto7;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:27\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto8;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:25\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto9;
	
	@AndroidFindBy(xpath ="//android.widget.FrameLayout[@content-desc=\"Photo, September 13, 2022 15:23:20\"]/android.widget.FrameLayout/android.widget.TextView")
	private AndroidElement ophoto10;
	
	@AndroidFindBy(accessibility ="OK")
	private AndroidElement ook;
	
	@AndroidFindBy(accessibility ="Submit")
	private AndroidElement osubmit;
	
	
	public AndroidElement getoDefaultLogin() {
    	return oDefaultLogin;
    }
    public AndroidElement getoDefaultLoginHeader() {
    	return oLoginHeader;
    }
    public AndroidElement getoDefaultPasswordToAccessYourAcctText() {
    	return oEnterYourEmailAddressText;
    }
    public AndroidElement getoPasswordToAccessYourAcctText() {
    	return oPasswordToAccessYourAcctText;
    }
    
    public AndroidElement getoUserName() {
    	return oUserName;
    	
    }
    public AndroidElement getoPassWord() {
    	return oPassWord;
    }
    public AndroidElement getoLogin() {
    	return OLogin;
    }
	
    public AndroidElement getocoursetab() {
		return ocoursetab;
    	
    }
    public AndroidElement getolanguage() {
		return olanguage;
    	
    }
    public AndroidElement getotopic() {
		return otopic;
    	
    }
    public AndroidElement getothridtopic() {
		return othridtopic;
    	
    }
    public AndroidElement getopermission() {
		return opermission;
    	
    }
    public AndroidElement getonotetitle() {
		return onotetitle;
    	
    }
    public AndroidElement getoenternote() {
		return oenternote;
    	
    }
    public AndroidElement getouploadfile() {
		return ouploadfile;
    	
    }
    public AndroidElement getogallery() {
		return ogallery;
    	
    }
    public AndroidElement getoallowbutton() {
		return oallowbutton;
    	
    }
    public AndroidElement getoselectgallery() {
		return oselectgallery;
    	
    }
    
    public AndroidElement getosubmit() {
		return osubmit;
    	
    }
    public AndroidElement getophoto1(){
		return ophoto1;
    	
    }
    public AndroidElement getophoto2(){
		return ophoto2;

	
    }
    public AndroidElement getophoto3(){
		return ophoto3;
    	
    }
    	
    
    public AndroidElement getophoto4(){
		return ophoto4;
    }
    public AndroidElement getophoto5(){
		return ophoto5;
    }
    public AndroidElement getophoto6(){
		return ophoto6;
    }
    public AndroidElement getophoto7(){
		return ophoto7;
    }
    public AndroidElement getophoto8(){
		return ophoto8;
    }
    public AndroidElement getophoto9(){
		return ophoto9;
    }
    public AndroidElement getophoto10(){
		return ophoto10;
    	
    }
    public AndroidElement getook() {
		return ook;
    	
    }
    	
    }
   
