package StudentFeedback;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import CoursesDetails.CourseDetails;
import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;


	
	public class StudentFeedbackTest extends BaseTest{


		
		StudentFeedback StudentObject;   // sprint 50 Aio test case 198
		
		
		@Test(dataProvider="loginData")
		public void ValidCredentials(String email,String password) throws InterruptedException {
			test = extent.startTest("To verify add indivdual rating & rating in course  by student ").assignCategory("Regression Test");
			StudentObject = new StudentFeedback(driver);
			
			Thread.sleep(15000);
			clickOnElement(StudentObject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Default Login");
			
			VerifyelementIsDisplayed(StudentObject.getoDefaultLoginHeader());
			test.log(LogStatus.PASS, "Login Header Is Displayed");
			
			VerifyelementIsDisplayed(StudentObject.getoDefaultPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
			
			
			VerifyelementIsDisplayed(StudentObject.getoPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
			
			clickOnElement(StudentObject.getoUserName());
			Thread.sleep(1000);
			sendValuesToElement(StudentObject.getoUserName(), email);
			test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
			
			clickOnElement(StudentObject.getoPassWord());
			Thread.sleep(1000);
			sendValuesToElement(StudentObject.getoPassWord(),password);
			test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
			
			Thread.sleep(12000);
			clickOnElement(StudentObject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Login");
			
			Thread.sleep(10000);
			clickOnElement(StudentObject.getoCoureseButton());
	        test.log(LogStatus.PASS,"clicked on course button");
	        
//	        Thread.sleep(8000);
//			(new TouchAction(driver)).press(PointOption.point(982, 1823))
//			  .moveTo(PointOption.point(975, 250))
//			  .release()
//			  .perform();
//			
	        
	        Thread.sleep(10000);
	        clickOnElement(StudentObject.getoLanguages());
	        test.log(LogStatus.PASS, "clicked on the languages course");
	        
	        Thread.sleep(8000);
	       
	       
	         (new TouchAction(driver)).tap(PointOption.point(202, 1152)).perform();   //   193, 1112
	    	Thread.sleep(5000);

//	        test.log(LogStatus.PASS,"clicked on review feedback");
//	        Thread.sleep(10000);
	        
	       

	       
		}
		private String getoUserName() {
			return null;
			// TODO Auto-generated method stub
			//	return null;
		}

		@DataProvider(name="loginData")
		public Object[][] getLoginData() throws IOException{
			return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet_33.xlsx", "Sheet1", "StudentFeedbackTest");
		}
}
