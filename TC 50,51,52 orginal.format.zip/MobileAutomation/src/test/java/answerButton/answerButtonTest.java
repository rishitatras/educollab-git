package answerButton;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class answerButtonTest extends BaseTest {

	answerButton answerObject;  // sprint 61 Aio test case 
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify answer button for assessment").assignCategory("Regression Test");
		answerObject = new answerButton (driver);
		
		Thread.sleep(4000);
		clickOnElement(answerObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		
		VerifyelementIsDisplayed(answerObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(answerObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(answerObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(2000);
		//sendValuesToElement(CoursesObject.getoUserName(), email);
		clickOnElement(answerObject.getoUserName());
		Thread.sleep(500);
		sendValuesToElement(answerObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(500);
		clickOnElement(answerObject.getoPassWord());
		sendValuesToElement(answerObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		Thread.sleep(8000);
		buttonClick(answerObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		clickOnElement(answerObject.getoCoureseButton());
		test.log(LogStatus.PASS,"clicked on the CoureseButton ");
		
//		Thread.sleep(8000);
//		(new TouchAction(driver)).press(PointOption.point(982, 1823))
//		  .moveTo(PointOption.point(975, 250))
//		  .release()
//		  .perform();
		
		Thread.sleep(8000);
		clickOnElement(answerObject.getolanguage());
		test.log(LogStatus.PASS,"clicked on the language ");
		
		
		Thread.sleep(8000);
		clickOnElement(answerObject.getocourseresources());
		test.log(LogStatus.PASS,"clicked on the courseresource ");
		
		Thread.sleep(8000);
		clickOnElement(answerObject.getoinstructor());
		test.log(LogStatus.PASS,"clicked on the instructor ");
		
		Thread.sleep(8000);
		clickOnElement(answerObject.getolivesession());
		test.log(LogStatus.PASS,"clicked on the livesession ");
		
		Thread.sleep(8000);
		clickOnElement(answerObject.getoassessmenttab());
		test.log(LogStatus.PASS,"clicked on the assessmenttab ");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(806, 1855)).perform();
		
		
	Thread.sleep(5000);
	(new TouchAction(driver)).tap(PointOption.point(558, 1504)).perform();
	
//		(new TouchAction(driver)).press(PointOption.point(898, 2097))
//		  .moveTo(PointOption.point(894, 1701))
//		  .release()
//		  .perform();
//		Thread.sleep(1000);
		
		
		test.log(LogStatus.PASS,"clicked on answer button displayeds");
		
		
		Thread.sleep(4000);
//		.press(PointOption.point(817, 1627}))
//		  .moveTo(PointOption.point(814, 179}))
//		  .release()
//		  .perform();
//	
//		Thread.sleep(10000);
//		PointOption(FeaturedObject.getoFeaturedCourse());
//		test.log(LogStatus.PASS,"clicked on course");
		

}
	
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet_3.xlsx", "Sheet1", "answerButtonTest");
	}

	

	
	
}
