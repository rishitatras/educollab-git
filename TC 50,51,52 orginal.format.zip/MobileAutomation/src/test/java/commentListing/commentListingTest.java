package commentListing;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class commentListingTest extends BaseTest { // sprint 54 test case AIO test no 295

	commentListing   commentobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify comments listing in a session ").assignCategory("Regression Test");
		commentobject = new commentListing(driver);
		
		Thread.sleep(10000);
		clickOnElement(commentobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(commentobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(commentobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(commentobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(3000);
		clickOnElement(commentobject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(commentobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(commentobject.getoPassWord());
		sendValuesToElement(commentobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(8000);
		clickOnElement(commentobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		clickOnElement(commentobject.getocoursetab());
		test.log(LogStatus.PASS, "Clicked on coursetab");
		Thread.sleep(8000);
		
//		(new TouchAction(driver)).press(PointOption.point(982, 1823))
//		  .moveTo(PointOption.point(975, 250))
//		  .release()
//		  .perform();
//		
		
		Thread.sleep(8000);
		clickOnElement(commentobject.getolanguage());
		test.log(LogStatus.PASS, "Clicked on languages");
		
		Thread.sleep(8000);
		clickOnElement(commentobject.getotopic());
		test.log(LogStatus.PASS, "Clicked on topic");
		
		Thread.sleep(15000);
		clickOnElement(commentobject.getothridtopic());
		test.log(LogStatus.PASS, "Clicked on thirdtopic");
		
		Thread.sleep(12000);
		clickOnElement(commentobject.getocomment());
		test.log(LogStatus.PASS, "Clicked on comment tab");
		Thread.sleep(1000);
		
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet_6.xlsx", "Sheet1", "commentListingTest");
	}		
		
		
		
		 
	
	
	

}
