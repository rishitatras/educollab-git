package addNotes;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import notesListing.notesListing;

public class addNotesTest extends BaseTest { // sprint 54 test case AIO test no 290

	addNotes   addobject;
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password,String notesTitle,String enterNotes) throws InterruptedException {
		test = extent.startTest("To verify Add note  functionality ").assignCategory("Regression Test");
		addobject = new addNotes(driver);
		
		Thread.sleep(10000);
		clickOnElement(addobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		VerifyelementIsDisplayed(addobject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(addobject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(addobject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
			clickOnElement(addobject.getoUserName());
		
		sendValuesToElement(addobject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(3000);
		clickOnElement(addobject.getoPassWord());
		sendValuesToElement(addobject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
        Thread.sleep(12000);
		clickOnElement(addobject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(12000);
		clickOnElement(addobject.getocoursetab());
		test.log(LogStatus.PASS, "Clicked on coursetab");
		
//		Thread.sleep(8000);
//		(new TouchAction(driver)).press(PointOption.point(982, 1823))
//		  .moveTo(PointOption.point(975, 250))
//		  .release()
//		  .perform();
//		
		
		Thread.sleep(10000);
		clickOnElement(addobject.getolanguage());
		test.log(LogStatus.PASS, "Clicked on languages");
		
		Thread.sleep(10000);
		clickOnElement(addobject.getotopic());
		test.log(LogStatus.PASS, "Clicked on topic");
		
		
		(new TouchAction(driver)).press(PointOption.point(926, 964))  //  926, 964
		  .moveTo(PointOption.point(930 , 714))  //930 , 714
		  .release()
		  .perform();
		
		
		Thread.sleep(16000);
		clickOnElement(addobject.getothridtopic());
		test.log(LogStatus.PASS, "Clicked on thirdtopic");
		
		Thread.sleep(10000);
		(new TouchAction(driver)).tap(PointOption.point(950, 2064)).perform();   //964, 2125
		
		Thread.sleep(12000);
		(new TouchAction(driver)).tap(PointOption.point(943, 1953)).perform();  //943, 1953

		
		
		Thread.sleep(5000);
		clickOnElement(addobject.getopermission());
		test.log(LogStatus.PASS, "Clicked on permission button");
		
		Thread.sleep(8000);
		clickOnElement(addobject.getonotetitle());
		Thread.sleep(1000);
		sendValuesToElement(addobject.getonotetitle(),notesTitle);
		test.log(LogStatus.PASS, "Clicked on notes title");
		
		Thread.sleep(8000);
		clickOnElement(addobject.getoenternote());
		Thread.sleep(1000);
		sendValuesToElement(addobject.getoenternote(),enterNotes);
		test.log(LogStatus.PASS, "Clicked on enter note");
		
		Thread.sleep(5000);
		(new TouchAction(driver)).press(PointOption.point(842, 715))//799,684
		  .moveTo(PointOption.point(831, 98)) //844,168
		  .release()
		  .perform();
//		(new TouchAction(driver)).tap(PointOption.point(782, 2314)).perform();
//		Thread.sleep(3000);
//		(new TouchAction(driver)).tap(PointOption.point(835, 2149)).perform();

		
		Thread.sleep(5000);
		clickOnElement(addobject.getosubmit());
		test.log(LogStatus.PASS, "Clicked on submit");
		
		
//		Thread.sleep(5000);
//		(new TouchAction(driver)).tap(PointOption.point(894, 2142)).perform();
 Thread.sleep(3000);
 
	}
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet_1.xlsx", "Sheet1", "addNotesTest");
	}					

	
	
	
	
}
