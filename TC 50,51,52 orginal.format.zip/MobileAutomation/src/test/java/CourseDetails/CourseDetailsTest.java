package CourseDetails;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import CoursesDetails.CourseDetails;
import EduCollab.Mobile.LoginPage.libraries.LoginPageObjects;
import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class CourseDetailsTest extends BaseTest{


	
		CourseDetails CoursesObject;       // sprint 50 Aio test case 176
		
		
		@Test(dataProvider="loginData")
		public void ValidCredentials(String email,String password) throws InterruptedException {
			test = extent.startTest("To verify subscribed course details page").assignCategory("Regression Test");
			CoursesObject = new CourseDetails(driver);
			Thread.sleep(10000);
			clickOnElement(CoursesObject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Default Login");
			Thread.sleep(1000);
			VerifyelementIsDisplayed(CoursesObject.getoDefaultLoginHeader());
			test.log(LogStatus.PASS, "Login Header Is Displayed");
			
			VerifyelementIsDisplayed(CoursesObject.getoDefaultPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
			
			VerifyelementIsDisplayed(CoursesObject.getoPasswordToAccessYourAcctText());
			test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
			
			Thread.sleep(8000);
			//sendValuesToElement(CoursesObject.getoUserName(), email);
			clickOnElement(CoursesObject.getoUserName());
			Thread.sleep(1000);
			sendValuesToElement(CoursesObject.getoUserName(), email);
			test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
			
			clickOnElement(CoursesObject.getoPassWord());
			Thread.sleep(8000);
			sendValuesToElement(CoursesObject.getoPassWord(),password);
			Thread.sleep(1000);
			test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
			
			//(CoursesObject.getoDefaultLogin());
			Thread.sleep(8000);
			buttonClick(CoursesObject.getoDefaultLogin());
			test.log(LogStatus.PASS, "Clicked on Login");
			
			Thread.sleep(8000);
			buttonClick(CoursesObject.getoCoureseButton());
	        test.log(LogStatus.PASS,"clicked on course button");
	        
	       
//	        Thread.sleep(8000);
//			(new TouchAction(driver)).press(PointOption.point(982, 1823))
//			  .moveTo(PointOption.point(975, 250))
//			  .release()
//			  .perform();
//			
	        
			 Thread.sleep(8000);
	        buttonClick(CoursesObject.getoLanguages());
	        test.log(LogStatus.PASS, "clicked on the languages coures");
	        
	        Thread.sleep(15000);
	        buttonClick(CoursesObject.getoTopicsAndCurriculum());
	        test.log(LogStatus.PASS,"Default topicandcurriculum is selected");


		}

		private String getoUserName() {
			return null;
			// TODO Auto-generated method stub
			//	return null;
		}

		@DataProvider(name="loginData")
		public Object[][] getLoginData() throws IOException{
			return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet_7.xlsx", "Sheet1", "CourseDetailsTest");
		}
	        
	        
	        
	        
	        
	        
}
