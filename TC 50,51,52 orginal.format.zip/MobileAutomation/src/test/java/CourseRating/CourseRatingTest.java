package CourseRating;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import CoursesDetails.CourseDetails;
import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class CourseRatingTest extends BaseTest {

	CourseRating RatingObject;    // sprint 50 test case 180
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify course rating in course details screen").assignCategory("Regression Test");
		RatingObject = new CourseRating(driver);
	
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		clickOnElement(RatingObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		//Thread.sleep(5000);
		VerifyelementIsDisplayed(RatingObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(RatingObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(RatingObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		//Thread.sleep(8000);
		clickOnElement(RatingObject.getoUserName());
		Thread.sleep(1000);
		sendValuesToElement(RatingObject.getoUserName(), email);
		//Thread.sleep(1000);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
	//	Thread.sleep(8000);
		clickOnElement(RatingObject.getoPassWord());
		Thread.sleep(1000);
		sendValuesToElement(RatingObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
	//	Thread.sleep(8000);
		buttonClick(RatingObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
	//	Thread.sleep(8000);
		buttonClick(RatingObject.getoCoureseButton());
        test.log(LogStatus.PASS,"clicked on course button");
        
     //   Thread.sleep(8000);
//		(new TouchAction(driver)).press(PointOption.point(982, 1823))
//		  .moveTo(PointOption.point(975, 250))
//		  .release()
//		  .perform();
//		
        
     //   Thread.sleep(12000);
        buttonClick(RatingObject.getoLanguages());
        test.log(LogStatus.PASS, "clicked on the languages coures");
        
     //   Thread.sleep(10000);
//        VerifyelementIsDisplayed(RatingObject.getoCourseRating());
//        test.log(LogStatus.PASS,"Course rating is displayed");
//        
        
	} 
	private String getoUserName() {
		return null;
		// TODO Auto-generated method stub
		//	return null;
	}

	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet_8.xlsx", "Sheet1", "CourseRatingTest");
	}
}
