package FeaturedCourse;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import EduCollab.Mobile.utilities.BaseTest;
import EduCollab.Mobile.utilities.JavaFunctions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.offset.PointOption;

public class FeaturedCourseTest extends BaseTest {

	FeaturedCourse FeaturedObject;  // sprint 50 Aio test case 235
	
	
	@Test(dataProvider="loginData")
	public void ValidCredentials(String email,String password) throws InterruptedException {
		test = extent.startTest("To verify see more Design & functionality for our featured course").assignCategory("Regression Test");
		FeaturedObject = new FeaturedCourse (driver);
		
		Thread.sleep(4000);
		clickOnElement(FeaturedObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Default Login");
		
		Thread.sleep(5000);
		VerifyelementIsDisplayed(FeaturedObject.getoDefaultLoginHeader());
		test.log(LogStatus.PASS, "Login Header Is Displayed");
		
		VerifyelementIsDisplayed(FeaturedObject.getoDefaultPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Enter Your Email Address Text is Displayed in Login Page ");
		
		VerifyelementIsDisplayed(FeaturedObject.getoPasswordToAccessYourAcctText());
		test.log(LogStatus.PASS, "Password To Access Your Acct Text is Displayed in Login Page ");
		
		Thread.sleep(2000);
		//sendValuesToElement(CoursesObject.getoUserName(), email);
		clickOnElement(FeaturedObject.getoUserName());
		Thread.sleep(500);
		sendValuesToElement(FeaturedObject.getoUserName(), email);
		test.log(LogStatus.PASS, "Entered the UserName data "+email+" in UserName");
		
		Thread.sleep(500);
		clickOnElement(FeaturedObject.getoPassWord());
		sendValuesToElement(FeaturedObject.getoPassWord(),password);
		test.log(LogStatus.PASS, "Entered the Password data "+password+" in Password");
		
		Thread.sleep(4000);
		buttonClick(FeaturedObject.getoDefaultLogin());
		test.log(LogStatus.PASS, "Clicked on Login");
		
		Thread.sleep(8000);
		clickOnElement(FeaturedObject.getOHomeTab());
		test.log(LogStatus.PASS,"clicked on the Home tab");
		
		Thread.sleep(1000);
		(new TouchAction(driver)).press(PointOption.point(817, 1550))
		  .moveTo(PointOption.point(714, 50))
		  .release()
		  .perform();
		Thread.sleep(1000);
		
		
		test.log(LogStatus.PASS,"clicked on featured course");
		Thread.sleep(5000);
		(new TouchAction(driver)).tap(PointOption.point(936, 2069)).perform();
		
		Thread.sleep(4000);
//		.press(PointOption.point(817, 1627}))
//		  .moveTo(PointOption.point(814, 179}))
//		  .release()
//		  .perform();
//	
//		Thread.sleep(10000);
//		PointOption(FeaturedObject.getoFeaturedCourse());
//		test.log(LogStatus.PASS,"clicked on course");
		System.out.println("Test Case PASSED");

}
	
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws IOException{
		return new JavaFunctions().getTableArray(System.getProperty("user.dir")+"/data/EduDataSheet_14.xlsx", "Sheet1", "FeaturedCourseTest");
	}
}
