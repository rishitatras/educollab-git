package web.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class deletequestionObject extends BaseTest {

	public deletequestionObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
		
	}
	@FindBy(xpath="//a[normalize-space()='Student Questions']")
	private WebElement studentquestion;
	
	public WebElement studentquestion() {
		return studentquestion;
		
	}
    @FindBy(xpath="//div[3]//div[2]//a[1]//i[1]")
    private WebElement deleteicon;
    
    public WebElement deleteicon() {
		return deleteicon;
    	
    }
    @FindBy(xpath="//button[normalize-space()='NO']")
    private WebElement noicon;
    
    public WebElement noicon() {
		return noicon;
    	
    }
		@FindBy(xpath="//body[1]/app-root[1]/main[1]/app-my-questions[1]/div[1]/div[1]/section[2]/div[1]/div[2]/div[7]/div[2]/a[2]")
	    private WebElement yesicon;
	    
	    public WebElement yesicon() {
			return yesicon;
	    	
	    }
}
