package web.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class myanswserObject extends BaseTest {

	public myanswserObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
	}
	@FindBy(xpath="//li[contains(@class,'nav-item student-dropdown ng-star-inserted dropdown')]//a[@id='navbarDropdown']")
	private WebElement studentcorner;
	
	public WebElement studentcorner() {
		return studentcorner;
		
	}
	@FindBy(xpath="//a[normalize-space()='All Questions']")
	private WebElement allquestion;
	
	public WebElement allquestion() {
		return allquestion;
	
	}
	@FindBy(xpath="(//i[@class='fa fa-angle-right'])[2]")
	private WebElement clickarrow;
	
	public WebElement clickarrow() {
		return clickarrow;
	
	}
	@FindBy(xpath="//button[normalize-space()='Write Your Answer']")
	private WebElement writeanswer;
	
	public WebElement writeanswer() {
		return writeanswer;
	
}
	@FindBy(xpath="//body[@id='tinymce']")
	private WebElement writeanswerbox;
	
	public WebElement writeanswerbox() {
		return writeanswerbox;
	}
	//input[@title=' ']
	@FindBy(xpath="//input[@title=' ']")
	private WebElement file;
	
	public WebElement file() {
		return file;
}
	@FindBy(xpath="//button[normalize-space()='Discard']")
	private WebElement discardbtn;
	
	public WebElement discardbtn() {
		return discardbtn;
}
}
	