package web.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class verifystudentObject extends BaseTest {

	public verifystudentObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")   
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
	}
	@FindBy(xpath="//li[@class='nav-item student-dropdown ng-star-inserted dropdown']//a[@id='navbarDropdown']")
	private WebElement studentcorner;
	
	public WebElement studentcorner() {
		return studentcorner;
	}
	
	@FindBy(xpath="//a[normalize-space()='All Questions']")
	private WebElement allquestion;
	
	public WebElement allquestion() {
		return allquestion;
	}
	
	@FindBy(xpath="//div[@class='questionBankLists mb-4 ng-star-inserted']//div[1]//a[1]//i[1]")
	private WebElement meenuicon;
	
	public WebElement meenuicon() {
		return meenuicon;
	}
	@FindBy(xpath="//body[1]/app-root[1]/main[1]/app-question-details[1]/div[1]/section[2]/div[1]/div[5]/div[2]/a[1]/i[1]")
	private WebElement answermeenu;
	
	public WebElement answermeenu() {
		return answermeenu;
	}
	
}

