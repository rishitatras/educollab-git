package web.homepage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class pickupleftObject extends BaseTest {

	public pickupleftObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
		
	}
	@FindBy(xpath ="//a[text()='Categories']")
	private WebElement category;
	
	public WebElement category() {
		return category;
		
    }
	@FindBy(xpath ="//a[text()='Performing Arts']")
	private WebElement course;
	
	public WebElement course() {
		return course;
	}
	@FindBy(xpath ="//a[normalize-space()='Music']")
	private WebElement subcourse;
	
	public WebElement subcourse() {
		return subcourse;
	}
	@FindBy(xpath ="//body[1]/app-root[1]/main[1]/app-category-list[1]/div[1]/div[1]/div[1]/div[3]/div[2]/figure[1]/img[1]")
	private WebElement maincourse;
	
	public WebElement maincourse() {
		return maincourse;
	}
	@FindBy(xpath ="//i[@class='fas fa-angle-down']")
	private WebElement topic;
	
	public WebElement topic() {
		return topic;
	}
	@FindBy(xpath ="//strong[normalize-space()='Arts and Music']")
	private WebElement sessiontopic;
	
	public WebElement sessiontopic() {
		return sessiontopic;
    }
	@FindBy(xpath ="//img[contains(@alt,'logo.png')]")
	private WebElement logo;
	
	public WebElement logo() {
		return logo;
}

	
}
	
	

