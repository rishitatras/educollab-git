package web.transcription;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class stddroptabObject extends BaseTest {

	public stddroptabObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
		
	}
	@FindBy(xpath ="//strong[@title='Automation Regression Testing']")
	private WebElement mycourse;
	
	public WebElement mycourse() {
		return mycourse;
	}
	@FindBy(xpath ="//span[text()='1. Transcription Testing ']")
	private WebElement topic;
	
	public WebElement topic() {
		return topic;
	}
	@FindBy(xpath ="//strong[normalize-space()='Transcription2']")
	private WebElement sessionlevel;
	
	public WebElement sessionlevel() {
		return sessionlevel;
	
	}
	@FindBy(xpath ="//a[text()='Transcription']")
	private WebElement transcriptiontab;
	
	public WebElement transcriptiontab() {
		return transcriptiontab;
	}
	@FindBy(xpath ="//div[@id='active-2-header']//i[@class='fas fa-angle-down']")
	private WebElement droptab;
	
	public WebElement droptab() {
		return droptab;
	
	
}


	
	
}
