package web.homeCategory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class maincategoryObject extends BaseTest {

	public maincategoryObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
		
	}
	@FindBy(xpath ="//a[@class='nav-link dropdown-toggle dropdown-toggle']")
	private WebElement mangement;
	
	public WebElement mangement() {
		return mangement;
		
	}
	@FindBy(xpath ="//a[text()='Manage Categories']")
	private WebElement managecategories;
	
	public WebElement managecategories() {
		return managecategories;
		
	}
	@FindBy(xpath ="//button[text()='Add new Category']")
	private WebElement addcategories;
	
	public WebElement addcategories() {
		return addcategories;
		
}
	@FindBy(xpath ="//input[@type='text']")
	private WebElement categoriename;
	
	public WebElement categoriename() {
		return categoriename;
		
	}
	
		@FindBy(xpath ="//select[@class='form-control ng-untouched ng-pristine ng-invalid']")
		private WebElement parentcategories;
		
		public WebElement parentcategories() {
			return parentcategories;
			
		}
		@FindBy(xpath ="//button[@type='submit']")
		private WebElement save;
		
		public WebElement save() {
			return save;
		}
		
		@FindBy(xpath ="//a[text()='Courses']")
		private WebElement course;
		
		public WebElement course() {
			return course;
		}
		@FindBy(xpath ="//a[text()='Published Courses']")
		private WebElement publishcourse;
		
		public WebElement publishcourse() {
			return publishcourse;
		
		}
		@FindBy(xpath ="//button[normalize-space()='+ Create New Course']")
		private WebElement addcourse;
		
		public WebElement addcourse() {
			return addcourse;

		}
		@FindBy(xpath ="//select[@formcontrolname='course_class']")
		private WebElement coursetype;
		
		public WebElement coursetype() {
			return coursetype;
		}
		@FindBy(xpath ="//select[@formcontrolname='course_category_id']")
		private WebElement category;
		
		public WebElement category() {
			return category;
		}
		
			
		@FindBy(xpath ="//input[@formcontrolname='subject']")
		private WebElement title;
		
		public WebElement title() {
			return title;
         }
		
		@FindBy(xpath ="//body[@id='tinymce']")
		private WebElement objective;
		
		public WebElement objective() {
			return objective;
		}
		@FindBy(xpath ="//body[@id='tinymce']")
		private WebElement browse;
		
		public WebElement browse() {
			return browse;
		
		}
		@FindBy(xpath ="//button[normalize-space()='Remove']")
		private WebElement remove;
		
		public WebElement remove() {
			return remove;
		}
		@FindBy(xpath ="//input[@placeholder='Enter Organisations']")
		private WebElement accessible;
		
		public WebElement accessible() {
			return accessible;
		
		
        }
		@FindBy(xpath ="//input[@placeholder='Enter instructors']")
		private WebElement instructors;
		
		public WebElement instructors() {
			return instructors;
		}
		@FindBy(xpath ="//input[@placeholder='Enter editors']")
	       private WebElement editors;

	  public WebElement editors() {
		return editors;
			
        }
      @FindBy(xpath ="//input[@placeholder='Enter Teaching Assistant']")
       private WebElement teachingassist;

       public WebElement teachingassist() {
	   return teachingassist;
      }
       @FindBy(xpath ="//button[@fdprocessedid='uxwejr']//i[@class='fas fa-times-circle']")
       private WebElement topic;

       public WebElement topic() {
	   return topic;
      }
       @FindBy(xpath ="//mat-expansion-panel-header[@id='mat-expansion-panel-header-28']//i[@class='fas fa-times-circle']")
       private WebElement coursework;

       public WebElement coursework() {
	   return coursework;
       
       }
       @FindBy(xpath ="//mat-expansion-panel-header[@id='mat-expansion-panel-header-29']//i[@class='fas fa-times-circle']")
       private WebElement assessment;

       public WebElement assessment() {
	   return assessment;
	   
       }
       @FindBy(xpath ="//mat-expansion-panel-header[@id='mat-expansion-panel-header-30']//i[@class='fas fa-times-circle']")
       private WebElement courseresource;

       public WebElement courseresource() {
	   return courseresource;
       }
       @FindBy(xpath ="//button[normalize-space()='Publish']")
       private WebElement publishbtn;

       public WebElement publishbtn() {
	   return publishbtn;
       }
     }