package web.homeCategory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class listingpageObject  extends BaseTest {

	public listingpageObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
		
	}
	@FindBy(xpath ="//a[text()='Categories']")
	private WebElement category;
	
	public WebElement category() {
		return category;
		
	}
	@FindBy(xpath ="//a[normalize-space()='Computer Science']")
	private WebElement Commerce;
	
	public WebElement Commerce() {
		return Commerce;
		
	
	}
	@FindBy(xpath ="//a[@aria-label='> page']")
	private WebElement nextpage;
	
	public WebElement nextpage() {
		return nextpage;
		
}
	@FindBy(xpath ="//a[@aria-label='< page']")
	private WebElement prevpage;
	
	public WebElement prevpage() {
		return prevpage;
	
}
}