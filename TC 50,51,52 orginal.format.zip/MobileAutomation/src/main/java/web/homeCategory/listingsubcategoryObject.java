package web.homeCategory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class listingsubcategoryObject extends BaseTest {

	public listingsubcategoryObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
		
	}
	@FindBy(xpath ="//a[text()='Categories']")
	private WebElement category;
	
	public WebElement category() {
		return category;
		
	}
	@FindBy(xpath ="//a[normalize-space()='Computer Science']")
	private WebElement computer;
	
	public WebElement computer() {
		return computer;
		
	
	}

	@FindBy(xpath ="//a[text()='Artificial Intelligence']")
	private WebElement subcategory;
	
	public WebElement subcategory() {
		return subcategory;
		
	
}
	
}
