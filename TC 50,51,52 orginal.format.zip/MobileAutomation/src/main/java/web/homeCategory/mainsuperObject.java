package web.homeCategory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class mainsuperObject extends BaseTest {

	public mainsuperObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
		
	}
	@FindBy(xpath ="//a[text()=' Management ']")
	private WebElement management;
	
	public WebElement management() {
		return management;
		
	}
	@FindBy(xpath ="//a[normalize-space()='Manage Categories']")
	private WebElement managecategory;
	
	public WebElement managecategory() {
		return managecategory;
		
	
	}
	@FindBy(xpath ="//button[normalize-space()='Add new Category']")
	private WebElement addcategory;
	
	public WebElement addcategory() {
		return addcategory;
	}	
	
	@FindBy(xpath ="//input[@type='text']")
	private WebElement category;
	
	public WebElement category() {
		return category;
	
     }

	@FindBy(xpath ="//select[@class='form-control ng-untouched ng-pristine ng-invalid']")
	private WebElement parentcategory;
	
	public WebElement parentcategory() {
		return parentcategory;
	
	}

	@FindBy(xpath ="//button[normalize-space()='Save']")
	private WebElement save;
	
	public WebElement save() {
		return save;
	}
	
}