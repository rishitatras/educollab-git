package web.assessment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EduCollab.Web.utilities.BaseTest;

public class topicsuperObject extends BaseTest {  //669

	public topicsuperObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginBtn;

	public WebElement login() {
		return loginBtn;
	}
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;
	
	public WebElement email() {
		return email;
	}
	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;
	
	public WebElement password() {
		return password;
	}
	@FindBy(xpath ="//button[@class='btn btn-lg btn-primary w-100']")
	private WebElement loginicon;
	
	public WebElement loginicon() {
		return loginicon;
		
		
	}
	@FindBy(xpath ="//li[@class='nav-item ng-star-inserted dropdown']//a[text()=' Resources ']")
	private WebElement resources;
	
	public WebElement resources() {
		return resources;
	}
	@FindBy(xpath ="//a[text()='Assessment']")
	private WebElement assessmenttab;
	
	public WebElement assessmenttab() {
		return assessmenttab;
	}
	
   }
