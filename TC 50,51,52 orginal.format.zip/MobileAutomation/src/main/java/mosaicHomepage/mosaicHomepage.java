package mosaicHomepage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class mosaicHomepage {

	

	public mosaicHomepage(WebDriver driver) {
			PageFactory.initElements(new AppiumFieldDecorator(driver), this);
			
		}
	// @AndroidFindBy(accessibility ="Login")

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Login']")
	private AndroidElement oDefaultLogin;
	
 
    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Login']")
    private AndroidElement oLoginHeader;
    
    @AndroidFindBy(accessibility = "Enter your email address and")
    private AndroidElement oEnterYourEmailAddressText;
    
	    
	    @AndroidFindBy(accessibility = "password to access your account")
	    private AndroidElement oPasswordToAccessYourAcctText;
	    
	    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]")
	    private AndroidElement oUserName;
	    
	    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]")
	    private AndroidElement oPassWord;
	    
	    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Login\"]")
	    private AndroidElement OLogin;
	    
	    @AndroidFindBy(accessibility ="Menu\nTab 5 of 5")  
	    private AndroidElement OMeenubar;
	    
	    @AndroidFindBy(accessibility ="The Mosaic")  
	    private AndroidElement omosaic;
	    
	    
	    
	    public AndroidElement getoDefaultLogin() {
	    	return oDefaultLogin;
	    }
	    public AndroidElement getoDefaultLoginHeader() {
	    	return oLoginHeader;
	    }
	    public AndroidElement getoDefaultPasswordToAccessYourAcctText() {
	    	return oEnterYourEmailAddressText;
	    }
	    public AndroidElement getoPasswordToAccessYourAcctText() {
	    	return oPasswordToAccessYourAcctText;
	    }
	    
	    public AndroidElement getoUserName() {
	    	return oUserName;
	    	
	    }
	    public AndroidElement getoPassWord() {
	    	return oPassWord;
	    }
	    public AndroidElement getoLogin() {
	    	return OLogin;
	    }
	    public AndroidElement getOMeenubar() {
			return OMeenubar;
	    	
	    }
	    
	    public AndroidElement getomosaic() {
			return omosaic;
		
			
	    	
	    }
	    
	    
	    
	    
	    
	    
	
}
